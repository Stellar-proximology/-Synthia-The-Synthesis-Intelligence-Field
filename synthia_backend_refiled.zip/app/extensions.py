# Flask extensions (e.g., db, migrate) setup
