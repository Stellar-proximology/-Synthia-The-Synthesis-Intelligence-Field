def mirror_reflection(prompt, sentence, cynthia):
    base_response = cynthia.reflect(sentence)
    if "clarity" in sentence:
        insight = "Your Gate is likely 64 or 47 — linked to mental pressure."
    elif "chaos" in sentence:
        insight = "This may relate to Gate 36 or 35 — the wave of emotional experience."
    else:
        insight = "Field reflection is unique; journal the feeling to trace pattern."
    return f"{base_response} Insight: {insight}"