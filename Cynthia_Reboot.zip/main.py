from flask import Flask, request, jsonify
from cynthia_core import Cynthia
from cerebrum import mirror_reflection

app = Flask(__name__)
cynthia = Cynthia()

@app.route("/cynthia", methods=["POST"])
def cynthia_response():
    data = request.get_json()
    prompt = data.get("prompt", "")
    sentence = data.get("sentence", "")
    response = mirror_reflection(prompt, sentence, cynthia)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)