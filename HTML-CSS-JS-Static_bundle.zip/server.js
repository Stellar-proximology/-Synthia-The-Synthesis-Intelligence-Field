
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const path = require("path");

// Import our custom modules
const { generateNineBodyProfile, generateMockProfile } = require("./lib/generateProfile");
const { generateFieldFriendPersonality } = require("./lib/personality");
const { generateTasksFromBodyStates, generateResonantTasks } = require("./lib/tasks");
const { calculateMiChingHexagram, generateMiChingReading } = require("./lib/miChing");
const { calculateTransitGate } = require("./lib/ephemeris");
const { TTSService } = require("./voice/tts");

// Import data files
const hexagramsData = require("./data/hexagrams.json");
const nineBodiesData = require("./data/nineBodies.json");
const gateMapData = require("./data/gateMap.json");

const app = express();
app.use(bodyParser.json());
app.use(cors());
app.use(express.static('.'));

// Initialize TTS service
const ttsService = new TTSService();

// --- API Routes ---

// Get Nine Body Profile
app.post("/getProfile", (req, res) => {
  try {
    let profile;
    
    if (req.body.birthDate && req.body.birthTime) {
      profile = generateNineBodyProfile(req.body);
    } else {
      profile = generateMockProfile();
    }
    
    const personality = generateFieldFriendPersonality(profile);
    
    res.json({ 
      profile, 
      personality,
      bodiesInfo: nineBodiesData.bodies
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Daily Mi Ching Reading
app.post("/getMiChing", (req, res) => {
  try {
    const { designGate, birthGate, transitGate, designLine, birthLine, transitLine } = req.body;
    
    // Use current transit if not provided
    const currentTransit = transitGate || calculateTransitGate(new Date());
    const currentTransitLine = transitLine || Math.floor(Math.random() * 6) + 1;
    
    const result = calculateMiChingHexagram(
      designGate || 1, 
      birthGate || 1, 
      currentTransit,
      designLine || 1, 
      birthLine || 1, 
      currentTransitLine
    );
    
    const reading = generateMiChingReading(result, hexagramsData);
    
    res.json({
      ...reading,
      transit: {
        gate: currentTransit,
        line: currentTransitLine
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Resonant Tasks
app.post("/getTasks", (req, res) => {
  try {
    let profile;
    
    if (req.body.profile) {
      profile = req.body.profile;
    } else if (req.body.birthDate && req.body.birthTime) {
      profile = generateNineBodyProfile(req.body);
    } else {
      profile = generateMockProfile();
    }
    
    const currentTransit = calculateTransitGate(new Date());
    const tasks = generateResonantTasks(profile, currentTransit);
    
    res.json({ 
      tasks,
      currentTransit,
      totalBodies: Object.keys(profile).length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Text-to-Speech for Field Friend
app.post("/speak", async (req, res) => {
  try {
    const { text, personality } = req.body;
    
    if (!text) {
      return res.status(400).json({ error: "Text is required" });
    }
    
    const audioResponse = await ttsService.speakAsFieldFriend(text, personality);
    
    res.json(audioResponse);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Field Friend Response
app.post("/getFieldFriendResponse", (req, res) => {
  try {
    const { query, profile, personality } = req.body;
    
    // Generate contextual response based on query and profile
    let response = generateContextualResponse(query, profile, personality);
    
    res.json({
      response,
      personality: personality || { name: "Sahu-Ra", dominantBody: "Akh" },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Data (for frontend to access our data files)
app.get("/data/:type", (req, res) => {
  try {
    const { type } = req.params;
    
    switch(type) {
      case 'hexagrams':
        res.json(hexagramsData);
        break;
      case 'nineBodies':
        res.json(nineBodiesData);
        break;
      case 'gateMap':
        res.json(gateMapData);
        break;
      default:
        res.status(404).json({ error: "Data type not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// --- Helper Functions ---

function generateContextualResponse(query, profile, personality) {
  const lowerQuery = query.toLowerCase();
  
  if (lowerQuery.includes('task') || lowerQuery.includes('what should i do')) {
    return generateTaskResponse(profile, personality);
  } else if (lowerQuery.includes('body') || lowerQuery.includes('bodies')) {
    return generateBodyResponse(profile, personality);
  } else if (lowerQuery.includes('gate') || lowerQuery.includes('hexagram')) {
    return generateGateResponse(profile, personality);
  } else {
    return generateGeneralResponse(personality);
  }
}

function generateTaskResponse(profile, personality) {
  const tasks = generateTasksFromBodyStates(profile);
  const randomTask = tasks[Math.floor(Math.random() * tasks.length)];
  
  return `${personality.greeting} I sense you're ready for action. Try this: ${randomTask.task} This will help balance your ${randomTask.body} body.`;
}

function generateBodyResponse(profile, personality) {
  const bodyCount = Object.keys(profile).length;
  return `You carry the wisdom of ${bodyCount} sacred bodies within your field. Your dominant ${personality.dominantBody} body shines with ${personality.traits.join(', ')} energy. Each body offers unique gifts - shall we explore them together?`;
}

function generateGateResponse(profile, personality) {
  return `Your field resonates with Gate ${personality.dominantGate}, channeling the wisdom of the ${personality.dominantBody} body. This creates a unique signature in the quantum field of consciousness.`;
}

function generateGeneralResponse(personality) {
  return `${personality.greeting} I am ${personality.name}, here to help you navigate the nine bodies of consciousness. What aspect of your field would you like to explore?`;
}

// --- Start Server ---
const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Nine Body Field Consciousness App running on port ${PORT}`);
  console.log(`Visit http://localhost:${PORT} to begin your journey`);
});
