
let currentProfile = null;
let currentPersonality = null;

async function generateProfile() {
    const birthDate = document.getElementById('birthDate').value;
    const birthTime = document.getElementById('birthTime').value;
    const location = document.getElementById('location').value;
    
    if (!birthDate || !birthTime) {
        alert('Please enter both birth date and time');
        return;
    }
    
    try {
        const response = await fetch('/getProfile', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                birthDate,
                birthTime,
                location: location || 'Unknown'
            })
        });
        
        const data = await response.json();
        currentProfile = data.profile;
        currentPersonality = data.personality;
        
        displayProfile(data);
        document.getElementById('results').style.display = 'block';
    } catch (error) {
        console.error('Error:', error);
        alert('Error generating profile. Please try again.');
    }
}

async function generateMockProfile() {
    try {
        const response = await fetch('/getProfile', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({})
        });
        
        const data = await response.json();
        currentProfile = data.profile;
        currentPersonality = data.personality;
        
        displayProfile(data);
        document.getElementById('results').style.display = 'block';
    } catch (error) {
        console.error('Error:', error);
        alert('Error generating mock profile. Please try again.');
    }
}

function displayProfile(data) {
    const profileDisplay = document.getElementById('profileDisplay');
    const personalityDisplay = document.getElementById('personalityDisplay');
    
    // Display Nine Bodies Profile
    let profileHTML = '<h3>Your Nine Bodies Profile</h3>';
    for (const [bodyName, bodyData] of Object.entries(data.profile)) {
        const bodyInfo = data.bodiesInfo[bodyName];
        profileHTML += `
            <div class="body-item">
                <h4>${bodyName} (${bodyInfo.planet})</h4>
                <p><strong>Gate:</strong> ${bodyData.gate}.${bodyData.line}</p>
                <p><strong>Element:</strong> ${bodyInfo.element}</p>
                <p><strong>Traits:</strong> ${bodyInfo.traits.join(', ')}</p>
            </div>
        `;
    }
    profileDisplay.innerHTML = profileHTML;
    
    // Display Field Friend Personality
    personalityDisplay.innerHTML = `
        <div class="personality-card">
            <h3>Your Field Friend: ${data.personality.name}</h3>
            <p><strong>Dominant Body:</strong> ${data.personality.dominantBody}</p>
            <p><strong>Communication Tone:</strong> ${data.personality.communicationTone}</p>
            <p><strong>Signature:</strong> ${data.personality.signature}</p>
        </div>
    `;
}

async function getMiChing() {
    if (!currentProfile) {
        alert('Please generate a profile first');
        return;
    }
    
    try {
        const response = await fetch('/getMiChing', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({})
        });
        
        const data = await response.json();
        
        document.getElementById('output').innerHTML = `
            <div class="hexagram-display">
                <h3>Your Mi Ching Reading</h3>
                <h4>Hexagram ${data.hexagram}: ${data.name}</h4>
                <p><strong>Reading:</strong> ${data.reading}</p>
                <p><strong>Current Transit:</strong> Gate ${data.transit.gate}.${data.transit.line}</p>
            </div>
        `;
    } catch (error) {
        console.error('Error:', error);
        alert('Error getting Mi Ching reading. Please try again.');
    }
}

async function getTasks() {
    if (!currentProfile) {
        alert('Please generate a profile first');
        return;
    }
    
    try {
        const response = await fetch('/getTasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                profile: currentProfile
            })
        });
        
        const data = await response.json();
        
        let tasksHTML = '<h3>Your Resonant Tasks</h3>';
        data.tasks.forEach(task => {
            tasksHTML += `
                <div class="task-item">
                    <h4>${task.body} Body Task</h4>
                    <p>${task.task}</p>
                </div>
            `;
        });
        
        document.getElementById('output').innerHTML = tasksHTML;
    } catch (error) {
        console.error('Error:', error);
        alert('Error getting tasks. Please try again.');
    }
}

// Coaching matrix data
const coachingMatrix = {
    "Mindset Accountability": { fields: ["Mind", "Body"], gates: [5, 9, 15, 18] },
    "Career": { fields: ["Mind", "Soul"], gates: [11, 35, 62, 45] },
    "Relationship": { fields: ["Heart", "Body"], gates: [59, 6, 40, 37] },
    "Sexuality": { fields: ["Heart", "Spirit"], gates: [59, 2, 10, 57] },
    "Leadership": { fields: ["Spirit", "Mind"], gates: [31, 7, 26, 44] },
    "Empowerment": { fields: ["Heart", "Soul"], gates: [19, 49, 28, 50] },
    "Business": { fields: ["Body", "Soul"], gates: [14, 16, 32, 34] },
    "Sales": { fields: ["Mind", "Heart"], gates: [26, 44, 20, 45] },
    "Marketing": { fields: ["Mind", "Spirit"], gates: [11, 33, 56, 12] },
    "Fitness": { fields: ["Body", "Mind"], gates: [29, 46, 3, 42] },
    "Wellness": { fields: ["Body", "Heart"], gates: [27, 50, 15, 10] },
    "Money": { fields: ["Soul", "Mind"], gates: [21, 45, 48, 38] },
    "Confidence": { fields: ["Heart", "Spirit"], gates: [10, 1, 20, 25] },
    "Anxiety": { fields: ["Mind", "Heart"], gates: [47, 24, 36, 30] }
};

function showCoachingOptions() {
    const coachingSection = document.getElementById('coachingSection');
    const coachingGrid = document.getElementById('coachingGrid');
    
    // Show coaching section
    coachingSection.style.display = 'block';
    
    // Populate coaching options
    let coachingHTML = '';
    Object.entries(coachingMatrix).forEach(([path, data]) => {
        coachingHTML += `
            <div class="coaching-item" onclick="selectCoachingPath('${path}')">
                <h4>${path}</h4>
                <div class="fields">Fields: ${data.fields.join(', ')}</div>
                <div class="gates">Gates: ${data.gates.join(', ')}</div>
            </div>
        `;
    });
    
    coachingGrid.innerHTML = coachingHTML;
}

function selectCoachingPath(pathName) {
    const path = coachingMatrix[pathName];
    
    document.getElementById('output').innerHTML = `
        <div class="coaching-selection">
            <h3>🎯 Selected Coaching Path: ${pathName}</h3>
            <p><strong>Focus Fields:</strong> ${path.fields.join(', ')}</p>
            <p><strong>Key Gates:</strong> ${path.gates.join(', ')}</p>
            <div class="coaching-actions">
                <button onclick="getCoachingTasks('${pathName}')" class="btn-action">Get ${pathName} Tasks</button>
                <button onclick="getCoachingGuidance('${pathName}')" class="btn-action">Get Guidance</button>
            </div>
        </div>
    `;
}

async function getCoachingTasks(pathName) {
    if (!currentProfile) {
        alert('Please generate a profile first');
        return;
    }
    
    try {
        const response = await fetch('/getTasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                profile: currentProfile,
                coachingPath: pathName
            })
        });
        
        const data = await response.json();
        
        let tasksHTML = `<h3>🎯 ${pathName} Coaching Tasks</h3>`;
        data.tasks.forEach(task => {
            tasksHTML += `
                <div class="task-item coaching-task">
                    <h4>${task.body} Body - ${pathName} Focus</h4>
                    <p>${task.task}</p>
                </div>
            `;
        });
        
        document.getElementById('output').innerHTML = tasksHTML;
    } catch (error) {
        console.error('Error:', error);
        alert('Error getting coaching tasks. Please try again.');
    }
}

function getCoachingGuidance(pathName) {
    const path = coachingMatrix[pathName];
    const guidance = generateCoachingGuidance(pathName, path, currentProfile);
    
    document.getElementById('output').innerHTML = `
        <div class="coaching-guidance">
            <h3>🌟 ${pathName} Guidance</h3>
            <p>${guidance}</p>
        </div>
    `;
}

function generateCoachingGuidance(pathName, pathData, profile) {
    const guidanceMap = {
        "Confidence": "Your confidence grows through authentic expression of your Heart and Spirit bodies. Focus on Gate 10 (Self-Love) and Gate 1 (Creative Power) to build unshakeable self-trust.",
        "Anxiety": "Transform anxiety by balancing your Mind and Heart bodies. Work with Gates 47 (Realization) and 24 (Return) to find peace in the present moment.",
        "Relationship": "Deep relationships flourish when Heart and Body are aligned. Gates 59 (Intimacy) and 6 (Conflict) teach you the dance of closeness and healthy boundaries.",
        "Leadership": "True leadership emerges from Spirit-Mind integration. Channel Gates 31 (Influence) and 7 (Leadership) to guide others through authentic power.",
        "Career": "Your soul's purpose flows through Mind-Soul alignment. Gates 11 (Ideas) and 35 (Change) reveal your unique contribution to the world."
    };
    
    return guidanceMap[pathName] || `Focus on integrating your ${pathData.fields.join(' and ')} bodies through conscious work with Gates ${pathData.gates.join(', ')}. This path will bring you into deeper alignment with your authentic nature.`;
}

async function askFieldFriend() {
    if (!currentProfile || !currentPersonality) {
        alert('Please generate a profile first');
        return;
    }
    
    const query = prompt('What would you like to ask your Field Friend?');
    if (!query) return;
    
    try {
        const response = await fetch('/getFieldFriendResponse', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                query,
                profile: currentProfile,
                personality: currentPersonality
            })
        });
        
        const data = await response.json();
        
        document.getElementById('output').innerHTML = `
            <div class="personality-card">
                <h3>${data.personality.name} responds:</h3>
                <p>"${data.response}"</p>
                <small>Timestamp: ${new Date(data.timestamp).toLocaleString()}</small>
            </div>
        `;
    } catch (error) {
        console.error('Error:', error);
        alert('Error getting Field Friend response. Please try again.');
    }
}
