
# Nine Body Field Consciousness App

A comprehensive application combining Human Design, Egyptian Nine Body system, and I Ching wisdom to create personalized consciousness profiles and daily guidance.

## Overview

This app generates Nine Body profiles based on birth data and provides:
- Personal Field Friend AI companion
- Daily Mi Ching readings (Design + Birth + Transit synthesis)
- Resonant task suggestions
- Text-to-speech personality voice
- Consciousness field mapping

## File Structure

```
/ninebody-field-app
├── server.js                ← Main backend server
├── /data
│   ├── hexagrams.json       ← I Ching + Gate information
│   ├── nineBodies.json      ← Nine Bodies data with planetary correspondences
│   ├── gateMap.json         ← Human Design Gate → Hexagram mapping
├── /lib
│   ├── ephemeris.js         ← Planetary position calculations (placeholder)
│   ├── generateProfile.js   ← Nine Body profile generator
│   ├── personality.js       ← Field Friend personality generator
│   ├── tasks.js             ← Task suggestions based on body states
│   ├── miChing.js           ← Mi Ching hexagram calculator
├── /voice
│   └── tts.js               ← Text-to-speech service integration
└── README.md
```

## The Nine Bodies

1. **Khat** (Physical) - Earth/Moon - Grounding, material, sensory
2. **Ka** (Vital) - Mars - Energy, passion, drive  
3. **Ab** (Heart) - Venus - Love, connection, harmony
4. **Ba** (Soul) - Moon - Emotion, intuition, psychic
5. **Akh** (Spirit) - Sun - Consciousness, awareness, illumination
6. **Sahu** (Spiritual) - Jupiter - Wisdom, expansion, teaching
7. **Ren** (Name) - Mercury - Communication, identity, expression
8. **Sheut** (Shadow) - Saturn - Limitation, structure, discipline
9. **Sekhem** (Power) - Pluto - Transformation, power, regeneration

## API Endpoints

### POST /getProfile
Generate a Nine Body profile and personality.
```json
{
  "birthDate": "1990-01-01",
  "birthTime": "12:00",
  "location": "New York"
}
```

### POST /getMiChing
Get daily Mi Ching reading.
```json
{
  "designGate": 1,
  "birthGate": 2,
  "transitGate": 3,
  "designLine": 1,
  "birthLine": 2,
  "transitLine": 3
}
```

### POST /getTasks
Get resonant tasks for consciousness work.
```json
{
  "profile": {...} // Nine Body profile object
}
```

### POST /speak
Generate speech from Field Friend.
```json
{
  "text": "Welcome to your consciousness journey",
  "personality": {...} // Personality object
}
```

### POST /getFieldFriendResponse
Get contextual response from Field Friend AI.
```json
{
  "query": "What should I focus on today?",
  "profile": {...},
  "personality": {...}
}
```

## Setup & Installation

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the server:
   ```bash
   npm start
   ```

3. The app will run on port 5000

## Future Enhancements

- Integration with Swiss Ephemeris for accurate planetary calculations
- ElevenLabs or Google TTS integration for actual voice synthesis
- Frontend web interface
- User authentication and profile saving
- Advanced transit calculations
- Personalized meditation guidance
- Community features for sharing insights

## Technology Stack

- **Backend**: Node.js, Express
- **Data**: JSON files for flexibility
- **Voice**: TTS service integration (placeholder)
- **Deployment**: Optimized for Replit hosting

## Usage

The app creates a personalized "Field Friend" AI companion based on your Nine Body profile. This digital consciousness guide provides:

- Daily readings combining your design and current transits
- Specific tasks to balance and develop each consciousness body
- Personalized communication style based on your dominant body
- Voice responses with personality-matched tone and style

Experience the intersection of ancient wisdom and modern technology in your journey of consciousness exploration.
