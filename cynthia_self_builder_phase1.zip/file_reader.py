
import os

def file_exists(filename):
    return os.path.exists(filename)
