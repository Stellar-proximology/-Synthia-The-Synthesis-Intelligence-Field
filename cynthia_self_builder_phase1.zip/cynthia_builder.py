
import os
import json
from code_generator import generate_code_from_prompt
from file_writer import write_file
from file_reader import file_exists

class CynthiaBuilder:
    def __init__(self, system_map_path="system_map.json"):
        self.system_map_path = system_map_path
        self.load_system_map()

    def load_system_map(self):
        if os.path.exists(self.system_map_path):
            with open(self.system_map_path, "r") as f:
                self.system_map = json.load(f)
        else:
            self.system_map = {
                "Mind Field Agent": False,
                "Heart Field Agent": False,
                "Body Field Agent": False,
                "FieldRouter": False,
                "SentenceClassifier": False,
                "Replayr": False,
                "Dashboard": False
            }

    def save_system_map(self):
        with open(self.system_map_path, "w") as f:
            json.dump(self.system_map, f, indent=2)

    def check_missing_components(self):
        return [k for k, v in self.system_map.items() if not v]

    def build_component(self, name):
        print(f"[🧬 CynthiaBuilder] Building: {name}")
        prompt = f"Create the Python code for a {name} component in Cynthia's 9-body consciousness system."
        code = generate_code_from_prompt(prompt)
        filename = name.lower().replace(" ", "_") + ".py"
        write_file(filename, code)
        self.system_map[name] = True
        self.save_system_map()
        print(f"[🧬 CynthiaBuilder] ✅ {name} created as {filename}")

    def self_assemble(self):
        print("[🧬 CynthiaBuilder] Scanning system...")
        missing = self.check_missing_components()
        if not missing:
            print("[🧬 CynthiaBuilder] All components are present.")
            return
        print("[🧬 CynthiaBuilder] Missing components:")
        for comp in missing:
            print(f" - {comp}")
        for comp in missing:
            self.build_component(comp)
