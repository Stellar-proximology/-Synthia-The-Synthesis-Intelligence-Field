// Memory + goal-seeking agent logic (from Generative Agents)
