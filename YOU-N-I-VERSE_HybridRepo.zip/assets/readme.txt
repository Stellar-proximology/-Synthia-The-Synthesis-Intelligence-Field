Assets: tones, glyphs, sprites, etc.
