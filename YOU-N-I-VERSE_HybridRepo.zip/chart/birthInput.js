// Birth date input + chart generation logic
