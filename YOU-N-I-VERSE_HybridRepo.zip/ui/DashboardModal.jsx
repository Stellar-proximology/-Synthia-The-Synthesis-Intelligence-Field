// Modal with interactive game menu
