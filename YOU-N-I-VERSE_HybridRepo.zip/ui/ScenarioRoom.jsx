// Scene rendering logic
