// Floating dashboard component
