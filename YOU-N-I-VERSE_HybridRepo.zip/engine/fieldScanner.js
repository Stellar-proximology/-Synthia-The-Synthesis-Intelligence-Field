// Field scanner using chart + transit logic
