// server/models/Thought.js
const mongoose = require('mongoose');

const ThoughtSchema = new mongoose.Schema({
  node: { type: String, enum: ['Mind','Heart','Body'], required: true },
  channel: { type: String, enum: ['impulse','thought','action'], required: true },
  text: { type: String, default: '' },
  spoken: { type: Boolean, default: false },               // whether it was voiced/output
  action: { type: Object, default: null },                 // optional action payload (e.g., {type:'message', to:'…'})
  meta: { type: Object, default: {} },                     // arbitrary metadata (gate, mode, userId, etc.)
  confidence: { type: Number, default: 0.0 },
}, { timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' }});

ThoughtSchema.index({ createdAt: -1 });
ThoughtSchema.index({ node: 1, channel: 1, createdAt: -1 });

module.exports = mongoose.model('Thought', ThoughtSchema);
