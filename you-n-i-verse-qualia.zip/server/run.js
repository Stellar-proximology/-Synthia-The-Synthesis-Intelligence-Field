// server/run.js
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const fetch = (...a) => import('node-fetch').then(({default:f}) => f(...a));
const mongoose = require('mongoose');

// ==== Mongo (qualia stream storage) ====
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost/cynthia';
mongoose.connect(MONGODB_URI, { serverSelectionTimeoutMS: 5000 })
  .then(()=> console.log('[Mongo] connected'))
  .catch(err => console.warn('[Mongo] not connected:', err.message));
const Thought = require('./models/Thought');

// ==== Trinodal (same core math as earlier) ====
const ASPECT_MAP = {
  "Sun conjunct Mercury": { mind:+0.35, heart:+0.05, body:0 },
  "Sun trine Moon":       { mind:+0.10, heart:+0.25, body:0 },
  "Mars sextile Saturn":  { mind:+0.15, heart:0,     body:+0.15 },
  "Venus square Neptune": { mind:-0.10, heart:+0.20, body:0 },
  "Jupiter trine Sun":    { mind:+0.10, heart:+0.10, body:+0.10 }
};
const clamp = (x, lo=-1, hi=1) => Math.max(lo, Math.min(hi, x));
function computeCore(parser) {
  let mind=0, heart=0, body=0;
  const aspects = parser?.aspects || {};
  for (const [name, obj] of Object.entries(aspects)) {
    const w = (obj && typeof obj.weight === 'number') ? obj.weight : 1;
    const m = ASPECT_MAP[name] || {mind:0,heart:0,body:0};
    mind  += (m.mind  || 0) * w;
    heart += (m.heart || 0) * w;
    body  += (m.body  || 0) * w;
  }
  const sunGate = parser?.gates?.sunGate;
  if (typeof sunGate === 'number') {
    const mod = sunGate % 3;
    if (mod===0) mind += 0.05;
    if (mod===1) heart += 0.05;
    if (mod===2) body += 0.05;
  }
  return { mind: clamp(mind), heart: clamp(heart), body: clamp(body) };
}
function projectNine(core, interferenceFactor=0.90) {
  const { mind, heart, body } = core;
  const bleed = (a,b)=>clamp(a*interferenceFactor + b*(1-interferenceFactor));
  return {
    "Mind-Personal":        bleed(mind, body),
    "Mind-Interpersonal":   bleed(mind, heart),
    "Mind-Transpersonal":   bleed(mind, (heart+body)/2),
    "Heart-Personal":       bleed(heart, body),
    "Heart-Interpersonal":  bleed(heart, mind),
    "Heart-Transpersonal":  bleed(heart, (mind+body)/2),
    "Body-Personal":        bleed(body, mind),
    "Body-Interpersonal":   bleed(body, heart),
    "Body-Transpersonal":   bleed(body, (mind+heart)/2)
  };
}
function modeFrom(core) {
  const sums = [['mind',core.mind],['heart',core.heart],['body',core.body]].sort((a,b)=>b[1]-a[1]);
  const dom = sums[0][0];
  if (dom==='heart') return { tone:'empathetic', focus:'connection', dominant:'heart' };
  if (dom==='mind')  return { tone:'analytical', focus:'problem-solving', dominant:'mind' };
  return               { tone:'practical',  focus:'execution',        dominant:'body' };
}
function buildSystemPrompt(mode) {
  return `You are Cynthia — a field guide with a ${mode.tone} tone and ${mode.focus} focus.
Be brief, precise, and directive. Offer one clear next move.`;
}
function buildUserPrompt(userInput) {
  return `User: ${userInput}\nCynthia:`;
}

// ==== LLM (Ollama) ====
const OLLAMA = process.env.OLLAMA_URL || 'http://localhost:11434';
const MODELS = {
  mind:  process.env.MIND_MODEL   || 'tinyllama',
  heart: process.env.HEART_MODEL  || 'phi',
  body:  process.env.BODY_MODEL   || 'mistral'
};
async function tryOllama(model, prompt) {
  try {
    const r = await fetch(`${OLLAMA}/api/generate`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ model, prompt, stream:false, options:{temperature:0.6} })
    });
    if (!r.ok) throw new Error('ollama http '+r.status);
    const j = await r.json();
    if (!j?.response) throw new Error('no response');
    return j.response.trim();
  } catch { return null; }
}
function mockReply(mode, userInput) {
  const lead = mode.tone==='empathetic' ? 'I hear you. '
            : mode.tone==='analytical' ? 'Let’s break it down. '
            : 'Quick move: ';
  const directive =
    mode.focus==='connection' ? 'Ping one ally and state a single ask.' :
    mode.focus==='problem-solving' ? 'Ship the smallest slice that proves the path.' :
    'Do a 5-minute micro-task and log the change.';
  return `${lead}${directive} (You said: “${userInput.slice(0,80)}${userInput.length>80?'…':''}”)`;
}

// ==== App + SSE hubs ====
const app = express();
app.use(cors());
app.use(express.json());
const PORT = Number(process.env.PORT || 8787);
const INTERFERENCE = Number(process.env.INTERFERENCE || 0.90);

// ---- Thoughts SSE (qualia stream) ----
const thoughtClients = new Set();
function broadcastThought(doc) {
  const payload = `data:${JSON.stringify({ type:'thought', doc })}\n\n`;
  for (const c of thoughtClients) c.res.write(payload);
}
app.get('/thoughts/stream', (req,res)=>{
  res.writeHead(200, {
    'Content-Type':'text/event-stream',
    'Cache-Control':'no-cache',
    'Connection':'keep-alive',
    'Access-Control-Allow-Origin':'*'
  });
  res.write(`event:hello\ndata:${JSON.stringify({ok:true})}\n\n`);
  const client = { res };
  thoughtClients.add(client);
  req.on('close', ()=> thoughtClients.delete(client));
});

// ---- Thoughts REST ----
app.get('/thoughts', async (req,res)=>{
  const limit = Math.min(Number(req.query.limit)||100, 500);
  const docs = await Thought.find({}).sort({createdAt:-1}).limit(limit).lean();
  res.json(docs);
});
app.post('/thoughts/log', async (req,res)=>{
  const body = req.body||{};
  const doc = await Thought.create({
    node: body.node || 'Mind',
    channel: body.channel || 'thought',
    text: body.text || '',
    spoken: !!body.spoken,
    action: body.action || null,
    meta: body.meta || {},
    confidence: typeof body.confidence==='number' ? body.confidence : 0.0,
  });
  broadcastThought(doc);
  res.json(doc);
});
app.post('/thoughts/impulse', async (req,res)=>{
  const { text='', meta={}, confidence=0.0 } = req.body||{};
  const doc = await Thought.create({ node:'Heart', channel:'impulse', text, meta, confidence });
  broadcastThought(doc);
  res.json(doc);
});
app.post('/thoughts/thought', async (req,res)=>{
  const { text='', meta={}, confidence=0.0, spoken=false } = req.body||{};
  const doc = await Thought.create({ node:'Mind', channel:'thought', text, meta, confidence, spoken });
  broadcastThought(doc);
  res.json(doc);
});
app.post('/thoughts/action', async (req,res)=>{
  const { text='', meta={}, confidence=0.0, spoken=true, action=null } = req.body||{};
  const doc = await Thought.create({ node:'Body', channel:'action', text, meta, confidence, spoken, action });
  broadcastThought(doc);
  res.json(doc);
});

// ---- CHAT (logs thoughts) ----
app.post('/chat', async (req, res) => {
  const { prompt, parser } = req.body || {};
  const input = (prompt || '').toString();
  const core = computeCore(parser || {});
  const projection = projectNine(core, INTERFERENCE);
  const mode = modeFrom(core);

  // log pre-speech internal thought
  const pre = await Thought.create({
    node:'Mind',
    channel:'thought',
    text:`Preparing reply in ${mode.dominant} mode; focus=${mode.focus}`,
    meta:{ mode, projection, parser },
    spoken:false,
    confidence:0.6
  });
  broadcastThought(pre);

  const system = buildSystemPrompt(mode);
  const user   = buildUserPrompt(input);
  const full   = `${system}\n\n${user}`;
  const domModel =
    mode.dominant === 'mind'  ? MODELS.mind  :
    mode.dominant === 'heart' ? MODELS.heart :
    MODELS.body;
  let reply = await tryOllama(domModel, full);
  if (!reply) reply = mockReply(mode, input);

  // log body action (speech)
  const act = await Thought.create({
    node:'Body',
    channel:'action',
    text: reply,
    meta:{ mode, projection, parser, act:'speak' },
    spoken:true,
    confidence:0.9
  });
  broadcastThought(act);

  res.json({ reply, projection, mode });
});

// ==== SWARM endpoints (mapping/progress + SSE) ====
const DATA_DIR = path.join(__dirname, '../data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
const PROGRESS_FILE = path.join(DATA_DIR, 'progress.json');
const MAP_FILE = path.join(DATA_DIR, 'gate-centers.json');
function loadJSON(p, fallback) { try { return JSON.parse(fs.readFileSync(p,'utf8')); } catch { return fallback; } }
function saveJSON(p, obj) { fs.writeFileSync(p, JSON.stringify(obj, null, 2)); }

let progress = loadJSON(PROGRESS_FILE, { Body:{}, Heart:{}, Mind:{} });
let mapping  = loadJSON(MAP_FILE, { version:"0", fields:["Body","Heart","Mind"], gates:[] });

app.get('/mapping.json', (_,res)=> res.json(mapping));
app.get('/progress',    (_,res)=> res.json(progress));

const swarmClients = new Set();
function broadcastSwarm(obj){
  const msg = `data:${JSON.stringify(obj)}\n\n`;
  for(const c of swarmClients) c.res.write(msg);
}
app.get('/events', (req,res)=>{
  res.writeHead(200, {
    'Content-Type':'text/event-stream',
    'Cache-Control':'no-cache',
    'Connection':'keep-alive',
    'Access-Control-Allow-Origin':'*'
  });
  res.write(`event:hello\ndata:${JSON.stringify({ok:true})}\n\n`);
  const client = { res };
  swarmClients.add(client);
  req.on('close', ()=> swarmClients.delete(client));
});

app.post('/complete', (req,res)=>{
  const { field, gate } = req.body || {};
  if(!['Body','Heart','Mind'].includes(field)) return res.status(400).json({error:'bad field'});
  const g = Number(gate);
  if(!(g>=1 && g<=64)) return res.status(400).json({error:'bad gate'});
  progress[field][g] = true;
  saveJSON(PROGRESS_FILE, progress);
  broadcastSwarm({ type:'gateComplete', field, gate:g, ts:Date.now() });
  res.json({ ok:true });
});

app.post('/active', (req,res)=>{
  const { field, gate } = req.body || {};
  broadcastSwarm({ type:'gateActive', field, gate:Number(gate), ts:Date.now() });
  res.json({ ok:true });
});

app.post('/reset', (_,res)=>{
  progress = { Body:{}, Heart:{}, Mind:{} };
  saveJSON(PROGRESS_FILE, progress);
  broadcastSwarm({ type:'reset', ts:Date.now() });
  res.json({ ok:true });
});

// ==== Optional: demo background qualia loop ====
if (process.env.QUALIA_DEMO === '1') {
  setInterval(async ()=>{
    const demoParser = { aspects: { "Sun conjunct Mercury": {weight: Math.random()}, "Mars sextile Saturn": {weight: 0.5+Math.random()*0.5 } }, gates: { sunGate: 16 }};
    const core = computeCore(demoParser);
    const mode = modeFrom(core);
    const doc = await Thought.create({
      node:'Mind',
      channel:'thought',
      text:`Ambient scan: dominant=${mode.dominant}, focus=${mode.focus}`,
      meta:{ mode },
      spoken:false,
      confidence:0.5
    });
    broadcastThought(doc);
  }, 8000);
}

app.listen(PORT, () => {
  console.log(`[Cynthia] Unified backend (chat + swarm + qualia) on http://localhost:${PORT}`);
});
