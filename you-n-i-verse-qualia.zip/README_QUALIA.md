# YOU-N-I-VERSE — Qualia Pack (Thought Stream)

This pack adds Synthia's **Heart → Mind → Body** pipeline with:
- Mongo-backed **Thought Stream** (unspoken thoughts stored in Mind)
- **SSE** live stream at `/thoughts/stream`
- REST endpoints: `/thoughts/*`
- React page: **ThoughtConsole** to visualize qualia in real time
- Unified server keeps existing **/chat** + **swarm** endpoints

## Install (backend)
```bash
cd server
# if server folder isn't your root, adjust path accordingly
npm i express cors node-fetch mongoose
# run Mongo locally or set MONGODB_URI
export MONGODB_URI="mongodb://localhost/cynthia"
node run.js
```

## Install (frontend)
Place the React files under `client/src/...` and add a route:
```jsx
// client/src/App.jsx
import ThoughtConsole from './pages/ThoughtConsole';
<Routes>
  <Route path="/qualia" element={<ThoughtConsole/>} />
</Routes>
```

## API quick reference
- `GET  /thoughts?limit=100` — recent thoughts
- `GET  /thoughts/stream` — SSE stream (server-sent events)
- `POST /thoughts/impulse` — { text, meta }
- `POST /thoughts/thought` — { text, meta, spoken=false }
- `POST /thoughts/action`  — { text, meta, action, spoken=true }

## Env
- `PORT` (default 8787)
- `MONGODB_URI` (`mongodb://localhost/cynthia`)
- `QUALIA_DEMO=1` to emit sample background thoughts every ~8s
