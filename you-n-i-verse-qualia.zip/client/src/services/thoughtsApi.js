// client/src/services/thoughtsApi.js
export async function fetchThoughts(limit=100){
  const r = await fetch(`/thoughts?limit=${limit}`);
  if(!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}
export function openThoughtStream(onmsg){
  const es = new EventSource('/thoughts/stream');
  es.onmessage = (e)=> {
    try {
      const msg = JSON.parse(e.data||'{}');
      onmsg && onmsg(msg);
    } catch {}
  };
  return es;
}
export async function logImpulse(text, meta={}){
  const r = await fetch('/thoughts/impulse', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ text, meta })});
  if(!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}
export async function logThought(text, meta={}, spoken=false){
  const r = await fetch('/thoughts/thought', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ text, meta, spoken })});
  if(!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}
export async function logAction(text, meta={}, action=null, spoken=true){
  const r = await fetch('/thoughts/action', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ text, meta, action, spoken })});
  if(!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}
