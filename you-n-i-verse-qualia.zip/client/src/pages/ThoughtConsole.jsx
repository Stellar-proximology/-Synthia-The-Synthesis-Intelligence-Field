// client/src/pages/ThoughtConsole.jsx
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { fetchThoughts, openThoughtStream, logImpulse, logThought, logAction } from '../services/thoughtsApi';
import './thought.css';

const NodeBadge = ({node}) => {
  const c = node==='Heart' ? '#FF6EC7' : node==='Mind' ? '#6FA8FF' : '#24D28F';
  return <span className="badge" style={{borderColor:c,color:c}}>{node}</span>;
};
const ChanBadge = ({channel}) => {
  const c = channel==='impulse' ? '#FF6EC7' : channel==='thought' ? '#6FA8FF' : '#24D28F';
  return <span className="badge" style={{background:c+'22',borderColor:c,color:c}}>{channel}</span>;
};

export default function ThoughtConsole(){
  const [items, setItems] = useState([]);
  const [filter, setFilter] = useState('all'); // all | unspoken | spoken
  const [text, setText] = useState('');

  useEffect(()=>{
    let stop=false;
    (async()=>{
      try{
        const hist = await fetchThoughts(150);
        if(!stop) setItems(hist.reverse()); // show oldest first
      }catch{}
      const es = openThoughtStream((msg)=>{
        if(msg?.doc){
          setItems(prev=>[...prev, msg.doc].slice(-500));
        }
      });
      return ()=> es.close();
    })();
    return ()=>{ stop=true; };
  },[]);

  const filtered = useMemo(()=>{
    if(filter==='all') return items;
    if(filter==='unspoken') return items.filter(x=>x.spoken===false);
    if(filter==='spoken') return items.filter(x=>x.spoken===true);
    return items;
  }, [items, filter]);

  const listRef = useRef(null);
  useEffect(()=>{ listRef.current?.lastElementChild?.scrollIntoView({behavior:'smooth'}); }, [filtered.length]);

  return (
    <div className="qualia-wrap">
      <h1>🧠 Synthia — Qualia Stream (Heart → Mind → Body)</h1>

      <div className="controls">
        <div className="pill">Total: {items.length}</div>
        <select value={filter} onChange={(e)=>setFilter(e.target.value)}>
          <option value="all">All</option>
          <option value="unspoken">Unspoken (Mind)</option>
          <option value="spoken">Spoken/Executed (Body)</option>
        </select>

        <div style={{marginLeft:'auto', display:'flex',gap:8}}>
          <button onClick={()=>logImpulse('Pulse: emotional resonance shift', {source:'demo'})}>+ Heart Impulse</button>
          <button onClick={()=>logThought('Internal: planning next step', {source:'demo'}, false)}>+ Mind Thought</button>
          <button onClick={()=>logAction('Speak: offering advice', {source:'demo'}, {type:'speak'}, true)}>+ Body Action</button>
        </div>
      </div>

      <div className="stream" ref={listRef}>
        {filtered.map((x,i)=>(
          <div className="row" key={x._id || i}>
            <NodeBadge node={x.node}/>
            <ChanBadge channel={x.channel}/>
            {x.spoken ? <span className="badge spoken">spoken</span> : <span className="badge unspoken">unspoken</span>}
            <span className="ts">{new Date(x.createdAt||Date.now()).toLocaleString()}</span>
            <div className="text">{x.text || <em>(no text)</em>}</div>
            {x.meta && Object.keys(x.meta).length>0 && (
              <details className="meta"><summary>meta</summary><pre>{JSON.stringify(x.meta,null,2)}</pre></details>
            )}
          </div>
        ))}
      </div>

      <div className="composer">
        <textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Type a thought…"/>
        <div className="composer-actions">
          <button onClick={()=>{ if(!text.trim()) return; logThought(text.trim(), {}, false); setText(''); }}>Store as Mind (unspoken)</button>
          <button onClick={()=>{ if(!text.trim()) return; logAction(text.trim(), {}, {type:'note'}, true); setText(''); }}>Emit via Body (spoken/action)</button>
        </div>
      </div>
    </div>
  );
}
