import { OllamaService, OllamaConfig } from './ollama';
import { AstrologyService } from './astrology';
import { CollapseEngine } from './collapse';
import { CityManager } from './city-manager';
import { BirthData, ChartData, ConsciousnessResponse, CollapseResult } from '@shared/schema';

export interface ConsciousnessConfig {
  ollama: OllamaConfig;
  collapse?: {
    relevance?: number;
    coherence?: number;
    resonance?: number;
    safety?: number;
    confidence?: number;
  };
}

export class ConsciousnessService {
  private ollama: OllamaService;
  private astrology: AstrologyService;
  private collapse: CollapseEngine;
  private cityManager: CityManager;

  constructor(config: ConsciousnessConfig) {
    this.ollama = new OllamaService(config.ollama);
    this.astrology = new AstrologyService();
    this.collapse = new CollapseEngine(config.collapse);
    this.cityManager = new CityManager();
  }

  async processQuestion(question: string, chartData: ChartData): Promise<{
    responses: {
      body?: ConsciousnessResponse;
      mind?: ConsciousnessResponse;
      heart?: ConsciousnessResponse;
    };
    collapse: CollapseResult;
    cityStates: Record<string, any>;
  }> {
    console.log('Processing consciousness question through city networks:', question);
    
    // Use city manager to process the question across all districts
    const cityResult = await this.cityManager.processConsciousnessQuery(question, chartData);
    
    // Extract responses from city agents
    const responses: {
      body?: ConsciousnessResponse;
      mind?: ConsciousnessResponse;
      heart?: ConsciousnessResponse;
    } = {};

    if (cityResult.bodyResponse) {
      responses.body = cityResult.bodyResponse;
    }

    if (cityResult.mindResponse) {
      responses.mind = cityResult.mindResponse;
    }

    if (cityResult.heartResponse) {
      responses.heart = cityResult.heartResponse;
    }

    // Ensure at least one response succeeded
    if (Object.keys(responses).length === 0) {
      throw new Error('All city consciousness nodes failed to respond');
    }

    // Run collapse engine
    const collapseResult = await this.collapse.collapse(responses, chartData, question);

    return {
      responses,
      collapse: collapseResult,
      cityStates: cityResult.cityActivities
    };
  }

  async calculateChart(birthData: BirthData): Promise<ChartData> {
    return this.astrology.calculateChart(birthData);
  }

  async healthCheck(): Promise<{
    ollama: boolean;
    astrology: boolean;
    collapse: boolean;
  }> {
    const checks = {
      ollama: false,
      astrology: false,
      collapse: false
    };

    try {
      // Test Ollama connection
      await this.ollama.queryModel('tinyllama', 'test', 'You are a test. Respond with just "OK"');
      checks.ollama = true;
    } catch (error) {
      console.warn('Ollama health check failed:', error);
    }

    try {
      // Test astrology calculation
      const testBirth: BirthData = {
        date: '1990-01-01',
        time: '12:00',
        timezone: 'UTC',
        latitude: 0,
        longitude: 0,
        place: 'Test'
      };
      await this.astrology.calculateChart(testBirth);
      checks.astrology = true;
    } catch (error) {
      console.warn('Astrology health check failed:', error);
    }

    // Collapse engine is always available (no external dependencies)
    checks.collapse = true;

    return checks;
  }

  getCityStates(): Record<string, any> {
    return this.cityManager.getCityStates();
  }

  getAllAgents(): any[] {
    return this.cityManager.getAllAgents();
  }
}
