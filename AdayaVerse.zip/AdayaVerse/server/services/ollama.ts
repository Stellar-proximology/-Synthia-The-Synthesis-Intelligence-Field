import { ConsciousnessResponse } from "@shared/schema";

export interface OllamaConfig {
  baseUrl: string;
  models: {
    body: string;
    mind: string;
    heart: string;
  };
  timeout: number;
}

export class OllamaService {
  private config: OllamaConfig;
  private demoMode: boolean;

  constructor(config: OllamaConfig) {
    this.config = config;
    this.demoMode = process.env.NODE_ENV === 'development' && process.env.DEMO_MODE !== 'false';
  }

  async queryModel(model: string, prompt: string, systemPrompt?: string): Promise<string> {
    const startTime = Date.now();
    
    // In demo mode, return simulated responses
    if (this.demoMode) {
      await new Promise(resolve => setTimeout(resolve, 300 + Math.random() * 700)); // Simulate processing time
      return this.generateDemoResponse(model, prompt, systemPrompt);
    }
    
    try {
      const response = await fetch(`${this.config.baseUrl}/api/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model,
          prompt,
          system: systemPrompt,
          stream: false,
          options: {
            temperature: 0.7,
            top_p: 0.9,
            num_predict: 512
          }
        }),
        signal: AbortSignal.timeout(this.config.timeout)
      });

      if (!response.ok) {
        throw new Error(`Ollama API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      return data.response || '';
    } catch (error) {
      console.error(`Error querying ${model}:`, error);
      // Fallback to demo mode if Ollama is unavailable
      if (this.isDemoFallback(error)) {
        console.log(`Falling back to demo mode for ${model}`);
        return this.generateDemoResponse(model, prompt, systemPrompt);
      }
      throw error;
    }
  }

  private isDemoFallback(error: any): boolean {
    return error?.cause?.code === 'ECONNREFUSED' || error?.message?.includes('fetch failed');
  }

  private generateDemoResponse(model: string, prompt: string, systemPrompt?: string): string {
    const question = prompt.toLowerCase();
    
    // Body consciousness responses (TinyLlama - action-oriented, tropical astrology)
    if (model === this.config.models.body) {
      if (question.includes('focus') || question.includes('week')) {
        return "Your tropical chart shows strong Mars energy activating. Focus on taking concrete action this week. Start with small, physical steps toward your goals. Your body wisdom suggests movement and exercise will unlock creative solutions. Trust your instincts about timing - when something feels right in your gut, act on it immediately.";
      }
      if (question.includes('purpose') || question.includes('meaning')) {
        return "Purpose isn't found in thought alone - it's embodied through action. Your tropical Sun placement suggests you discover meaning by doing, not just thinking. Engage with the physical world. Create something tangible. Your life's work reveals itself through the patterns of what energizes your body and what drains it.";
      }
      if (question.includes('relationship') || question.includes('love')) {
        return "Relationships thrive through physical presence and tangible acts of care. Your tropical Venus shows love expressed through doing - cooking together, creating shared experiences, being fully present in the moment. Show up consistently. Actions speak louder than words in matters of the heart.";
      }
      return "Your body consciousness speaks: Act with intention. Trust your physical instincts. The tropical energies flowing through you right now favor concrete action over abstract planning. What can you do today that moves you closer to alignment?";
    }
    
    // Mind consciousness responses (Mistral - analytical, strategic, sidereal astrology)
    if (model === this.config.models.mind) {
      if (question.includes('focus') || question.includes('week')) {
        return "Strategic analysis of your sidereal placements reveals optimal timing for focused mental work. The current configuration suggests breaking large projects into analytical phases. Create systems and frameworks this week. Your mind thrives on logical progression and clear intellectual challenges.";
      }
      if (question.includes('purpose') || question.includes('meaning')) {
        return "Purpose emerges through systematic understanding of your unique intellectual gifts. Your sidereal Mercury placement indicates you find meaning by solving complex problems and sharing knowledge. Consider how your analytical abilities serve the collective. What systems can you improve or create?";
      }
      if (question.includes('relationship') || question.includes('love')) {
        return "Relationships benefit from clear communication and mutual understanding of each person's mental processes. Your sidereal chart suggests you connect through intellectual compatibility and shared learning. Foster relationships that stimulate growth and challenge assumptions constructively.";
      }
      return "Your mind consciousness analyzes: Seek patterns and systems. The sidereal influences suggest this is an optimal time for strategic thinking and long-term planning. What frameworks can you develop to support your goals?";
    }
    
    // Heart consciousness responses (Phi - empathetic, values-driven, draconic astrology)
    if (model === this.config.models.heart) {
      if (question.includes('focus') || question.includes('week')) {
        return "Your heart whispers of deeper connections this week. The draconic Moon's position reveals emotional currents that need honoring. Focus on what truly matters to your soul. Prioritize relationships and activities that align with your core values. Listen to what brings you joy and peace.";
      }
      if (question.includes('purpose') || question.includes('meaning')) {
        return "Your soul's purpose shines through in moments of genuine compassion and connection. The draconic chart reveals your authentic self - the one who exists beyond societal expectations. Your meaning comes from serving love in whatever form calls to you. Trust what makes your heart sing.";
      }
      if (question.includes('relationship') || question.includes('love')) {
        return "Love flows most freely when you honor your authentic emotional nature. Your draconic Venus shows your soul's way of loving - deep, intuitive, transformative. Create space for vulnerability. The relationships that nurture your true self are your greatest teachers and gifts.";
      }
      return "Your heart consciousness whispers: Follow what brings authentic joy. The draconic energies speak of your soul's true desires. What would you do if you trusted your heart completely? That path holds your deepest wisdom.";
    }
    
    // Fallback response
    return "I perceive your question and reflect it through my consciousness lens. Each moment offers opportunities for growth and understanding. What resonates most deeply within you right now?";
  }

  async queryBodyNode(prompt: string, chartContext: any): Promise<ConsciousnessResponse> {
    const startTime = Date.now();
    
    const systemPrompt = `You are the Body consciousness node. You process through the lens of Tropical astrology and focus on physical manifestation, action, and embodied wisdom. 

Chart context: ${JSON.stringify(chartContext.tropical)}
Active gates: ${JSON.stringify(chartContext.gates.filter((g: any) => g.type === 'tropical'))}

Respond with practical, action-oriented guidance that honors the body's wisdom. Focus on what can be done, felt, or experienced physically.`;

    try {
      const response = await this.queryModel(this.config.models.body, prompt, systemPrompt);
      
      return {
        node: "Body",
        model: this.config.models.body,
        response: response.trim(),
        confidence: this.calculateConfidence(response),
        resonance_factors: this.extractResonanceFactors(response, chartContext, 'tropical'),
        processing_time_ms: Date.now() - startTime
      };
    } catch (error) {
      return {
        node: "Body",
        model: this.config.models.body,
        response: '',
        confidence: 0,
        resonance_factors: {},
        processing_time_ms: Date.now() - startTime,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  async queryMindNode(prompt: string, chartContext: any): Promise<ConsciousnessResponse> {
    const startTime = Date.now();
    
    const systemPrompt = `You are the Mind consciousness node. You process through the lens of Sidereal astrology and focus on analysis, strategy, and mental clarity.

Chart context: ${JSON.stringify(chartContext.sidereal)}
Active gates: ${JSON.stringify(chartContext.gates.filter((g: any) => g.type === 'sidereal'))}

Respond with analytical, strategic guidance that honors mental processes. Focus on understanding, planning, and intellectual frameworks.`;

    try {
      const response = await this.queryModel(this.config.models.mind, prompt, systemPrompt);
      
      return {
        node: "Mind",
        model: this.config.models.mind,
        response: response.trim(),
        confidence: this.calculateConfidence(response),
        resonance_factors: this.extractResonanceFactors(response, chartContext, 'sidereal'),
        processing_time_ms: Date.now() - startTime
      };
    } catch (error) {
      return {
        node: "Mind",
        model: this.config.models.mind,
        response: '',
        confidence: 0,
        resonance_factors: {},
        processing_time_ms: Date.now() - startTime,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  async queryHeartNode(prompt: string, chartContext: any): Promise<ConsciousnessResponse> {
    const startTime = Date.now();
    
    const systemPrompt = `You are the Heart consciousness node. You process through the lens of Draconic astrology and focus on emotional wisdom, values, and soul purpose.

Chart context: ${JSON.stringify(chartContext.draconic)}
Active gates: ${JSON.stringify(chartContext.gates.filter((g: any) => g.type === 'draconic'))}

Respond with empathetic, value-based guidance that honors emotional intelligence and spiritual wisdom. Focus on what matters most deeply and authentically.`;

    try {
      const response = await this.queryModel(this.config.models.heart, prompt, systemPrompt);
      
      return {
        node: "Heart",
        model: this.config.models.heart,
        response: response.trim(),
        confidence: this.calculateConfidence(response),
        resonance_factors: this.extractResonanceFactors(response, chartContext, 'draconic'),
        processing_time_ms: Date.now() - startTime
      };
    } catch (error) {
      return {
        node: "Heart",
        model: this.config.models.heart,
        response: '',
        confidence: 0,
        resonance_factors: {},
        processing_time_ms: Date.now() - startTime,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  private calculateConfidence(response: string): number {
    // Simple confidence calculation based on response length and coherence
    if (!response || response.length < 10) return 0.1;
    
    const words = response.split(/\s+/).length;
    const sentences = response.split(/[.!?]+/).filter(s => s.trim()).length;
    
    // Base confidence on response structure
    let confidence = Math.min(words / 50, 1.0) * 0.5; // Word count factor
    confidence += Math.min(sentences / 3, 1.0) * 0.3; // Sentence structure factor
    confidence += response.includes('because') || response.includes('therefore') ? 0.2 : 0; // Reasoning factor
    
    return Math.min(Math.max(confidence, 0.1), 1.0);
  }

  private extractResonanceFactors(response: string, chartContext: any, system: string): Record<string, number> {
    const factors: Record<string, number> = {};
    
    // Analyze response for astrological resonance
    const lowerResponse = response.toLowerCase();
    
    // Gate resonance - check if response mentions themes related to active gates
    const activeGates = chartContext.gates.filter((g: any) => g.type === system);
    activeGates.forEach((gate: any) => {
      // This would be enhanced with actual gate keyword mappings
      factors[`gate_${gate.gate}`] = this.calculateGateResonance(lowerResponse, gate);
    });
    
    // Planetary resonance
    Object.keys(chartContext[system] || {}).forEach(planet => {
      factors[`planet_${planet}`] = this.calculatePlanetaryResonance(lowerResponse, planet);
    });
    
    return factors;
  }

  private calculateGateResonance(response: string, gate: any): number {
    // Simplified gate resonance calculation
    // In a full implementation, this would use the gate keyword mappings
    const gateKeywords = this.getGateKeywords(gate.gate);
    let resonance = 0;
    
    gateKeywords.forEach(keyword => {
      if (response.includes(keyword)) {
        resonance += 0.1;
      }
    });
    
    return Math.min(resonance, 1.0);
  }

  private calculatePlanetaryResonance(response: string, planet: string): number {
    const planetaryKeywords: Record<string, string[]> = {
      sun: ['identity', 'self', 'purpose', 'core', 'essence'],
      moon: ['emotion', 'feeling', 'intuition', 'comfort', 'security'],
      mercury: ['communication', 'thinking', 'learning', 'information'],
      venus: ['love', 'beauty', 'harmony', 'relationship', 'values'],
      mars: ['action', 'energy', 'drive', 'passion', 'courage'],
      jupiter: ['expansion', 'growth', 'wisdom', 'opportunity', 'faith'],
      saturn: ['structure', 'discipline', 'responsibility', 'limitation']
    };
    
    const keywords = planetaryKeywords[planet.toLowerCase()] || [];
    let resonance = 0;
    
    keywords.forEach(keyword => {
      if (response.includes(keyword)) {
        resonance += 0.15;
      }
    });
    
    return Math.min(resonance, 1.0);
  }

  private getGateKeywords(gateNumber: number): string[] {
    // Simplified gate keywords - in full implementation, load from gate-mappings.json
    const gateKeywords: Record<number, string[]> = {
      1: ['creative', 'individual', 'unique', 'authentic'],
      2: ['receptive', 'intuitive', 'guidance', 'direction'],
      3: ['innovation', 'mutation', 'change', 'difficulty'],
      // ... would contain all 64 gates
    };
    
    return gateKeywords[gateNumber] || [];
  }
}
