import { BirthData, ChartData } from "@shared/schema";

export interface PlanetaryPosition {
  degree: number;
  minute: number;
  second: number;
  sign: string;
  house: number;
}

export interface HDGate {
  gate: number;
  line: number;
  color: number;
  tone: number;
  base: number;
  planet: string;
  type: string;
}

export interface Aspect {
  type: string;
  orb: number;
  planets: string[];
  exact: boolean;
}

export class AstrologyService {
  private readonly SIGNS = [
    'Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo',
    'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'
  ];

  async calculateChart(birthData: BirthData): Promise<ChartData> {
    // In a real implementation, this would use Swiss Ephemeris
    // For now, we'll create a structured calculation that demonstrates the format
    
    const julianDay = this.dateToJulianDay(birthData.date, birthData.time);
    
    // Calculate tropical positions (standard Western astrology)
    const tropical = await this.calculateTropicalPositions(julianDay, birthData);
    
    // Calculate sidereal positions (Vedic astrology) 
    const sidereal = await this.calculateSiderealPositions(julianDay, birthData);
    
    // Calculate draconic positions (Moon's North Node as 0° Aries)
    const draconic = await this.calculateDraconicPositions(julianDay, birthData);
    
    // Calculate Human Design gates from planetary positions
    const gates = await this.calculateHDGates(tropical, sidereal, draconic);
    
    // Calculate aspects between planets
    const aspects = await this.calculateAspects(tropical);
    
    return {
      tropical,
      sidereal, 
      draconic,
      gates,
      aspects
    };
  }

  private dateToJulianDay(date: string, time: string): number {
    const [year, month, day] = date.split('-').map(Number);
    const [hour, minute] = time.split(':').map(Number);
    
    // Simplified Julian Day calculation
    const a = Math.floor((14 - month) / 12);
    const y = year + 4800 - a;
    const m = month + 12 * a - 3;
    
    const jdn = day + Math.floor((153 * m + 2) / 5) + 365 * y + Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) - 32045;
    const dayFraction = (hour + minute / 60) / 24;
    
    return jdn + dayFraction - 0.5;
  }

  private async calculateTropicalPositions(julianDay: number, birthData: BirthData): Promise<Record<string, PlanetaryPosition>> {
    // This would use Swiss Ephemeris in a real implementation
    // For demonstration, we'll calculate realistic-looking positions
    
    const planets = ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune', 'pluto'];
    const positions: Record<string, PlanetaryPosition> = {};
    
    // Base positions that change with Julian day for realistic variation
    const basePositions: Record<string, number> = {
      sun: (julianDay % 365.25) * (360 / 365.25), // Sun moves ~1 degree per day
      moon: (julianDay % 27.3) * (360 / 27.3), // Moon moves ~13 degrees per day
      mercury: (julianDay % 88) * (360 / 88), // Mercury orbit
      venus: (julianDay % 225) * (360 / 225), // Venus orbit
      mars: (julianDay % 687) * (360 / 687), // Mars orbit
      jupiter: (julianDay % 4333) * (360 / 4333), // Jupiter orbit
      saturn: (julianDay % 10759) * (360 / 10759), // Saturn orbit
      uranus: (julianDay % 30687) * (360 / 30687), // Uranus orbit
      neptune: (julianDay % 60190) * (360 / 60190), // Neptune orbit
      pluto: (julianDay % 90560) * (360 / 90560) // Pluto orbit
    };
    
    for (const planet of planets) {
      const totalDegrees = basePositions[planet] % 360;
      const degree = Math.floor(totalDegrees % 30);
      const minute = Math.floor((totalDegrees % 1) * 60);
      const second = Math.floor(((totalDegrees % 1) * 60 % 1) * 60);
      const signIndex = Math.floor(totalDegrees / 30);
      const sign = this.SIGNS[signIndex];
      const house = Math.floor(totalDegrees / 30) + 1; // Simplified house calculation
      
      positions[planet] = {
        degree,
        minute,
        second,
        sign,
        house: house > 12 ? house - 12 : house
      };
    }
    
    return positions;
  }

  private async calculateSiderealPositions(julianDay: number, birthData: BirthData): Promise<Record<string, PlanetaryPosition>> {
    // Sidereal astrology subtracts the ayanamsa (precession offset)
    const tropical = await this.calculateTropicalPositions(julianDay, birthData);
    const ayanamsa = 24; // Lahiri ayanamsa approximation
    
    const sidereal: Record<string, PlanetaryPosition> = {};
    
    for (const [planet, pos] of Object.entries(tropical)) {
      let totalDegrees = (pos.degree + pos.sign.indexOf(pos.sign) * 30 - ayanamsa) % 360;
      if (totalDegrees < 0) totalDegrees += 360;
      
      const degree = Math.floor(totalDegrees % 30);
      const minute = Math.floor((totalDegrees % 1) * 60);
      const second = Math.floor(((totalDegrees % 1) * 60 % 1) * 60);
      const signIndex = Math.floor(totalDegrees / 30);
      const sign = this.SIGNS[signIndex];
      const house = Math.floor(totalDegrees / 30) + 1;
      
      sidereal[planet] = {
        degree,
        minute,
        second,
        sign,
        house: house > 12 ? house - 12 : house
      };
    }
    
    return sidereal;
  }

  private async calculateDraconicPositions(julianDay: number, birthData: BirthData): Promise<Record<string, PlanetaryPosition>> {
    // Draconic chart uses Moon's North Node as 0° Aries reference point
    const tropical = await this.calculateTropicalPositions(julianDay, birthData);
    
    // Calculate North Node position (simplified)
    const nodePosition = (julianDay % 6798) * (360 / 6798); // 18.6 year cycle
    
    const draconic: Record<string, PlanetaryPosition> = {};
    
    for (const [planet, pos] of Object.entries(tropical)) {
      let totalDegrees = (pos.degree + this.SIGNS.indexOf(pos.sign) * 30 - nodePosition) % 360;
      if (totalDegrees < 0) totalDegrees += 360;
      
      const degree = Math.floor(totalDegrees % 30);
      const minute = Math.floor((totalDegrees % 1) * 60);
      const second = Math.floor(((totalDegrees % 1) * 60 % 1) * 60);
      const signIndex = Math.floor(totalDegrees / 30);
      const sign = this.SIGNS[signIndex];
      const house = Math.floor(totalDegrees / 30) + 1;
      
      draconic[planet] = {
        degree,
        minute,
        second,
        sign,
        house: house > 12 ? house - 12 : house
      };
    }
    
    return draconic;
  }

  private async calculateHDGates(
    tropical: Record<string, PlanetaryPosition>,
    sidereal: Record<string, PlanetaryPosition>,
    draconic: Record<string, PlanetaryPosition>
  ): Promise<HDGate[]> {
    const gates: HDGate[] = [];
    
    // Convert planetary positions to Human Design gates
    // Each planet in each system gets mapped to gates
    
    const systems = [
      { positions: tropical, type: 'tropical' },
      { positions: sidereal, type: 'sidereal' },
      { positions: draconic, type: 'draconic' }
    ];
    
    for (const system of systems) {
      for (const [planet, pos] of Object.entries(system.positions)) {
        const totalDegrees = pos.degree + this.SIGNS.indexOf(pos.sign) * 30;
        
        // Map to Human Design gates (64 gates across 360 degrees)
        const gate = Math.floor(totalDegrees / (360 / 64)) + 1;
        const gateSection = (totalDegrees % (360 / 64)) / (360 / 64);
        
        // Calculate line (1-6)
        const line = Math.floor(gateSection * 6) + 1;
        
        // Calculate color (1-6) 
        const lineSection = (gateSection * 6) % 1;
        const color = Math.floor(lineSection * 6) + 1;
        
        // Calculate tone (1-6)
        const colorSection = (lineSection * 6) % 1;
        const tone = Math.floor(colorSection * 6) + 1;
        
        // Calculate base (1-5)
        const toneSection = (colorSection * 6) % 1;
        const base = Math.floor(toneSection * 5) + 1;
        
        gates.push({
          gate: gate > 64 ? 64 : gate,
          line: line > 6 ? 6 : line,
          color: color > 6 ? 6 : color,
          tone: tone > 6 ? 6 : tone,
          base: base > 5 ? 5 : base,
          planet,
          type: system.type
        });
      }
    }
    
    return gates;
  }

  private async calculateAspects(positions: Record<string, PlanetaryPosition>): Promise<Aspect[]> {
    const aspects: Aspect[] = [];
    const planets = Object.keys(positions);
    const aspectTypes = [
      { name: 'conjunction', angle: 0, orb: 8 },
      { name: 'opposition', angle: 180, orb: 8 },
      { name: 'trine', angle: 120, orb: 6 },
      { name: 'square', angle: 90, orb: 6 },
      { name: 'sextile', angle: 60, orb: 4 }
    ];
    
    for (let i = 0; i < planets.length; i++) {
      for (let j = i + 1; j < planets.length; j++) {
        const planet1 = planets[i];
        const planet2 = planets[j];
        const pos1 = positions[planet1];
        const pos2 = positions[planet2];
        
        const deg1 = pos1.degree + this.SIGNS.indexOf(pos1.sign) * 30;
        const deg2 = pos2.degree + this.SIGNS.indexOf(pos2.sign) * 30;
        
        let angle = Math.abs(deg1 - deg2);
        if (angle > 180) angle = 360 - angle;
        
        for (const aspectType of aspectTypes) {
          const difference = Math.abs(angle - aspectType.angle);
          if (difference <= aspectType.orb) {
            aspects.push({
              type: aspectType.name,
              orb: difference,
              planets: [planet1, planet2],
              exact: difference < 1
            });
          }
        }
      }
    }
    
    return aspects;
  }
}
