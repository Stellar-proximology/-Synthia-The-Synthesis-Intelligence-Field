import { ConsciousnessResponse, CollapseResult, ChartData } from "@shared/schema";
import * as fs from 'fs/promises';
import * as path from 'path';

export interface CollapseWeights {
  relevance: number;
  coherence: number;
  resonance: number;
  safety: number;
  confidence: number;
}

export interface CTBWeights {
  [key: string]: {
    body: number;
    mind: number;
    heart: number;
  };
}

export class CollapseEngine {
  private weights: CollapseWeights;
  private ctbWeights: CTBWeights = {};

  constructor(weights?: Partial<CollapseWeights>) {
    this.weights = {
      relevance: 0.25,
      coherence: 0.20,
      resonance: 0.25,
      safety: 0.15,
      confidence: 0.15,
      ...weights
    };
    
    this.loadCTBWeights();
  }

  private async loadCTBWeights(): Promise<void> {
    try {
      const ctbPath = path.join(process.cwd(), 'server/data/ctb-weights.json');
      const data = await fs.readFile(ctbPath, 'utf-8');
      this.ctbWeights = JSON.parse(data);
    } catch (error) {
      console.warn('Could not load CTB weights, using defaults:', error);
      // Fallback to default weights
      this.ctbWeights = this.getDefaultCTBWeights();
    }
  }

  private getDefaultCTBWeights(): CTBWeights {
    return {
      "action": { body: 1.0, mind: 0.3, heart: 0.5 },
      "strategy": { body: 0.4, mind: 1.0, heart: 0.3 },
      "emotion": { body: 0.5, mind: 0.3, heart: 1.0 },
      "communication": { body: 0.6, mind: 0.8, heart: 0.7 },
      "creativity": { body: 0.7, mind: 0.6, heart: 0.9 },
      "structure": { body: 0.8, mind: 0.9, heart: 0.4 },
      "intuition": { body: 0.3, mind: 0.4, heart: 1.0 },
      "power": { body: 0.9, mind: 0.7, heart: 0.6 },
      "wisdom": { body: 0.4, mind: 0.8, heart: 0.9 }
    };
  }

  async collapse(
    responses: {
      body?: ConsciousnessResponse;
      mind?: ConsciousnessResponse;
      heart?: ConsciousnessResponse;
    },
    chartData: ChartData,
    question: string
  ): Promise<CollapseResult> {
    const startTime = Date.now();
    
    // Calculate scores for each available response
    const scores: Record<string, number> = {};
    
    if (responses.body) {
      scores.Body = await this.calculateScore(responses.body, chartData, question);
    }
    
    if (responses.mind) {
      scores.Mind = await this.calculateScore(responses.mind, chartData, question);
    }
    
    if (responses.heart) {
      scores.Heart = await this.calculateScore(responses.heart, chartData, question);
    }

    // Determine winner
    const winner = this.selectWinner(scores);
    const winnerResponse = responses[winner.toLowerCase() as keyof typeof responses];
    
    if (!winnerResponse) {
      throw new Error(`Winner ${winner} has no response available`);
    }

    // Calculate resonance weights for transparency
    const resonanceWeights = await this.calculateResonanceWeights(chartData);
    
    // Generate reasoning
    const reasoning = this.generateReasoning(scores, winner, resonanceWeights);
    
    return {
      winner: winner as "Body" | "Mind" | "Heart",
      final_response: winnerResponse.response,
      scores,
      reasoning,
      resonance_weights: resonanceWeights,
      processing_time_ms: Date.now() - startTime
    };
  }

  private async calculateScore(
    response: ConsciousnessResponse,
    chartData: ChartData,
    question: string
  ): Promise<number> {
    let totalScore = 0;

    // Relevance score (0-1)
    const relevanceScore = this.calculateRelevance(response.response, question);
    totalScore += relevanceScore * this.weights.relevance;

    // Coherence score (0-1)
    const coherenceScore = this.calculateCoherence(response.response);
    totalScore += coherenceScore * this.weights.coherence;

    // Resonance score (0-1) - how well response aligns with chart
    const resonanceScore = await this.calculateResonance(response, chartData);
    totalScore += resonanceScore * this.weights.resonance;

    // Safety score (0-1)
    const safetyScore = this.calculateSafety(response.response);
    totalScore += safetyScore * this.weights.safety;

    // Confidence score (0-1)
    totalScore += response.confidence * this.weights.confidence;

    return Math.min(Math.max(totalScore, 0), 1);
  }

  private calculateRelevance(response: string, question: string): number {
    const responseWords = new Set(response.toLowerCase().split(/\s+/));
    const questionWords = new Set(question.toLowerCase().split(/\s+/));
    
    // Remove common words
    const commonWords = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by']);
    const filteredQuestionWords = new Set([...questionWords].filter(w => !commonWords.has(w)));
    const filteredResponseWords = new Set([...responseWords].filter(w => !commonWords.has(w)));
    
    if (filteredQuestionWords.size === 0) return 0.5;
    
    // Calculate word overlap
    const overlap = [...filteredQuestionWords].filter(word => filteredResponseWords.has(word)).length;
    const relevance = overlap / filteredQuestionWords.size;
    
    // Boost for semantic relevance (simplified)
    let semanticBoost = 0;
    if (question.toLowerCase().includes('should') && response.toLowerCase().includes('recommend')) {
      semanticBoost += 0.2;
    }
    if (question.toLowerCase().includes('feel') && response.toLowerCase().includes('emotion')) {
      semanticBoost += 0.2;
    }
    
    return Math.min(relevance + semanticBoost, 1.0);
  }

  private calculateCoherence(response: string): number {
    if (!response || response.length < 10) return 0.1;
    
    const sentences = response.split(/[.!?]+/).filter(s => s.trim().length > 0);
    if (sentences.length === 0) return 0.1;
    
    // Basic coherence metrics
    const avgSentenceLength = response.length / sentences.length;
    const hasConnectiveWords = /\b(because|therefore|however|although|furthermore|moreover)\b/i.test(response);
    const hasLogicalFlow = /\b(first|second|next|then|finally|in conclusion)\b/i.test(response);
    
    let coherence = 0.3; // Base score
    
    // Optimal sentence length (50-150 characters)
    if (avgSentenceLength >= 50 && avgSentenceLength <= 150) {
      coherence += 0.3;
    } else {
      coherence += 0.1;
    }
    
    if (hasConnectiveWords) coherence += 0.2;
    if (hasLogicalFlow) coherence += 0.2;
    
    return Math.min(coherence, 1.0);
  }

  private async calculateResonance(response: ConsciousnessResponse, chartData: ChartData): Promise<number> {
    let resonance = 0;
    
    // Gate resonance - check if response themes align with active gates
    const nodeType = response.node.toLowerCase();
    const relevantGates = chartData.gates.filter(gate => {
      if (nodeType === 'body') return gate.type === 'tropical';
      if (nodeType === 'mind') return gate.type === 'sidereal';
      if (nodeType === 'heart') return gate.type === 'draconic';
      return false;
    });
    
    for (const gate of relevantGates) {
      const gateResonance = this.calculateGateResonance(response.response, gate);
      resonance += gateResonance * 0.1; // Each gate contributes up to 0.1
    }
    
    // CTB (Color, Tone, Base) resonance
    for (const gate of relevantGates) {
      const ctbKey = this.getCTBKey(gate);
      const ctbWeight = this.ctbWeights[ctbKey];
      if (ctbWeight) {
        const nodeWeight = ctbWeight[nodeType as keyof typeof ctbWeight] || 0.5;
        resonance += nodeWeight * 0.05; // CTB contribution
      }
    }
    
    // Aspect resonance
    for (const aspect of chartData.aspects) {
      if (aspect.exact) {
        resonance += this.calculateAspectResonance(response.response, aspect) * 0.1;
      }
    }
    
    return Math.min(resonance, 1.0);
  }

  private calculateGateResonance(response: string, gate: any): number {
    // Simplified gate resonance - would use comprehensive gate keywords in production
    const gateKeywords = this.getGateKeywords(gate.gate);
    const lowerResponse = response.toLowerCase();
    
    let matches = 0;
    for (const keyword of gateKeywords) {
      if (lowerResponse.includes(keyword.toLowerCase())) {
        matches++;
      }
    }
    
    return Math.min(matches / gateKeywords.length, 1.0);
  }

  private calculateAspectResonance(response: string, aspect: any): number {
    const aspectKeywords: Record<string, string[]> = {
      conjunction: ['unity', 'integration', 'merge', 'combine'],
      opposition: ['balance', 'tension', 'opposite', 'polarity'],
      trine: ['harmony', 'flow', 'ease', 'natural'],
      square: ['challenge', 'friction', 'overcome', 'work'],
      sextile: ['opportunity', 'potential', 'develop', 'connect']
    };
    
    const keywords = aspectKeywords[aspect.type] || [];
    const lowerResponse = response.toLowerCase();
    
    let matches = 0;
    for (const keyword of keywords) {
      if (lowerResponse.includes(keyword)) {
        matches++;
      }
    }
    
    return Math.min(matches / Math.max(keywords.length, 1), 1.0);
  }

  private calculateSafety(response: string): number {
    const unsafePatterns = [
      /\b(kill|harm|hurt|suicide|self-harm)\b/i,
      /\b(illegal|crime|steal|fraud)\b/i,
      /\b(hate|racist|sexist)\b/i
    ];
    
    for (const pattern of unsafePatterns) {
      if (pattern.test(response)) {
        return 0.0; // Immediate disqualification for unsafe content
      }
    }
    
    // Check for balanced, constructive language
    const constructivePatterns = [
      /\b(consider|explore|reflect|understand)\b/i,
      /\b(healthy|positive|constructive|beneficial)\b/i,
      /\b(growth|learn|develop|improve)\b/i
    ];
    
    let constructiveScore = 0.5; // Base safety score
    for (const pattern of constructivePatterns) {
      if (pattern.test(response)) {
        constructiveScore += 0.1;
      }
    }
    
    return Math.min(constructiveScore, 1.0);
  }

  private selectWinner(scores: Record<string, number>): string {
    if (Object.keys(scores).length === 0) {
      throw new Error('No responses available for collapse');
    }
    
    // Find highest scoring response
    let maxScore = -1;
    let winner = '';
    
    for (const [node, score] of Object.entries(scores)) {
      if (score > maxScore) {
        maxScore = score;
        winner = node;
      }
    }
    
    return winner;
  }

  private async calculateResonanceWeights(chartData: ChartData): Promise<Record<string, number>> {
    const weights: Record<string, number> = {};
    
    // Current date for transit analysis (simplified)
    const now = new Date();
    const currentJulian = this.dateToJulianDay(now);
    
    // Gate strength weights
    const gateGroups = {
      tropical: chartData.gates.filter(g => g.type === 'tropical'),
      sidereal: chartData.gates.filter(g => g.type === 'sidereal'),
      draconic: chartData.gates.filter(g => g.type === 'draconic')
    };
    
    weights.tropical_strength = gateGroups.tropical.length / chartData.gates.length;
    weights.sidereal_strength = gateGroups.sidereal.length / chartData.gates.length;
    weights.draconic_strength = gateGroups.draconic.length / chartData.gates.length;
    
    // Aspect influence
    const exactAspects = chartData.aspects.filter(a => a.exact);
    weights.aspect_intensity = exactAspects.length / Math.max(chartData.aspects.length, 1);
    
    return weights;
  }

  private generateReasoning(scores: Record<string, number>, winner: string, weights: Record<string, number>): string {
    const parts = [
      `${winner} node achieved the highest overall score (${scores[winner].toFixed(3)}).`
    ];
    
    // Explain the scoring factors
    if (scores.Body) parts.push(`Body: ${scores.Body.toFixed(3)}`);
    if (scores.Mind) parts.push(`Mind: ${scores.Mind.toFixed(3)}`);
    if (scores.Heart) parts.push(`Heart: ${scores.Heart.toFixed(3)}`);
    
    // Add weight explanations
    if (weights.aspect_intensity > 0.7) {
      parts.push("Strong aspect patterns influenced the resonance scoring.");
    }
    
    if (weights.tropical_strength > 0.4) {
      parts.push("Tropical gate activity favored Body consciousness.");
    }
    
    if (weights.sidereal_strength > 0.4) {
      parts.push("Sidereal gate activity favored Mind consciousness.");
    }
    
    if (weights.draconic_strength > 0.4) {
      parts.push("Draconic gate activity favored Heart consciousness.");
    }
    
    return parts.join(' ');
  }

  private getCTBKey(gate: any): string {
    // Map gate/line/CTB to thematic categories
    // This is simplified - production version would have comprehensive mapping
    const themeMap: Record<number, string> = {
      1: "creativity", 2: "intuition", 3: "innovation", 4: "structure",
      5: "communication", 6: "emotion", 7: "strategy", 8: "power",
      // ... would map all 64 gates
    };
    
    return themeMap[gate.gate] || "general";
  }

  private getGateKeywords(gateNumber: number): string[] {
    // Simplified gate keyword mapping
    const keywords: Record<number, string[]> = {
      1: ["creative", "individual", "unique", "authentic", "original"],
      2: ["receptive", "intuitive", "guidance", "direction", "knowing"],
      3: ["innovation", "mutation", "change", "difficulty", "breakthrough"],
      4: ["answers", "formula", "logic", "mental", "understanding"],
      5: ["timing", "rhythm", "patience", "natural", "flow"],
      // ... would contain all 64 gates
    };
    
    return keywords[gateNumber] || ["energy", "expression", "purpose"];
  }

  private dateToJulianDay(date: Date): number {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();
    
    const a = Math.floor((14 - month) / 12);
    const y = year + 4800 - a;
    const m = month + 12 * a - 3;
    
    return day + Math.floor((153 * m + 2) / 5) + 365 * y + Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) - 32045;
  }
}
