import { ChartData, ConsciousnessResponse } from "@shared/schema";
import { ElectronCollapseEngine } from "./electron-collapse";

export interface CityAgent {
  id: string;
  name: string;
  role: string;
  district: "Body" | "Mind" | "Heart";
  location: { x: number; y: number };
  status: "active" | "idle" | "busy" | "offline";
  activeCodens: number[]; // Active I Ching codons that determine skills
  skills: CodonSkill[];
  specialization: string[];
  currentTask?: string;
  memory: string[];
  relationships: Record<string, number>; // agent_id -> relationship_strength
  resonance: {
    color: number; // 1-6
    tone: number;  // 1-6
    base: number;  // 1-5
  };
}

export interface CodonSkill {
  codon: number;
  name: string;
  element: string;
  proficiency: number; // 0.0 - 1.0
  activeLines: number[]; // Which lines are active (1-6)
}

export interface CityDistrict {
  name: string;
  type: "Body" | "Mind" | "Heart";
  astrology_system: "tropical" | "sidereal" | "draconic";
  agents: CityAgent[];
  buildings: CityBuilding[];
  resources: Record<string, number>;
  activity_level: number;
  collapse_engine: ElectronCollapseEngine;
}

export interface CityBuilding {
  id: string;
  name: string;
  type: string;
  level: number;
  capacity: number;
  function: string;
  location: { x: number; y: number };
  status: "active" | "under_construction" | "inactive";
}

export interface CityTask {
  id: string;
  type: "consciousness_query" | "city_development" | "agent_interaction";
  question?: string;
  assigned_agents: string[];
  district: "Body" | "Mind" | "Heart";
  priority: number;
  status: "pending" | "in_progress" | "completed";
  result?: any;
  created_at: Date;
}

export class CityManager {
  private districts: Map<string, CityDistrict>;
  private agents: Map<string, CityAgent>;
  private tasks: Map<string, CityTask>;
  private gateData: any;
  private codonSkillMap: Map<number, string[]> = new Map();

  constructor() {
    this.districts = new Map();
    this.agents = new Map();
    this.tasks = new Map();
    this.initializeCodonSystem();
    this.initializeCities();
  }

  private initializeCodonSystem(): void {
    // Map I Ching gates to skill categories
    this.codonSkillMap = new Map([
      // Body/Physical skills (Tropical - Gates 1-21)
      [1, ["creative_expression", "leadership", "innovation", "authenticity"]],
      [2, ["intuition", "receptivity", "guidance", "sensitivity"]],
      [3, ["breakthrough", "transformation", "mutation", "chaos_navigation"]],
      [4, ["teaching", "logic", "understanding", "analysis"]],
      [5, ["timing", "patience", "rhythm", "natural_flow"]],
      [6, ["conflict_resolution", "emotional_intelligence", "intimacy", "peacemaking"]],
      [7, ["strategic_leadership", "direction", "influence", "democracy"]],
      [8, ["contribution", "role_modeling", "individuality", "fulfillment"]],
      [9, ["focus", "concentration", "attention_to_detail", "determination"]],
      [10, ["behavior_modification", "self_love", "survival_instinct", "life_force"]],
      
      // Mind/Mental skills (Sidereal - Gates 22-42)  
      [22, ["grace", "openness", "listening", "charm"]],
      [23, ["explanation", "insight", "splitting_apart", "individuality"]],
      [24, ["return", "rationalization", "natural_thinking", "renewal"]],
      [25, ["innocence", "spontaneity", "unexpected", "spirit_driven"]],
      [26, ["taming_power", "accumulated_energy", "ego_strength", "nurturing"]],
      [27, ["nourishment", "caring", "responsibility", "mothering"]],
      [28, ["struggle", "stubbornness", "life_death", "purpose_meaning"]],
      [29, ["commitment", "saying_yes", "abysmal", "depth"]],
      [30, ["recognition", "feelings", "emotional_intensity", "clinging_fire"]],
      [31, ["influence", "leadership", "stimulation", "attraction"]],
      [32, ["endurance", "continuity", "conservation", "duration"]],
      
      // Heart/Emotional skills (Draconic - Gates 43-64)
      [43, ["insight", "breakthrough", "individual_knowing", "determination"]],
      [44, ["coming_to_meet", "interaction", "partnership", "recognition"]],
      [45, ["gathering_together", "material_success", "king_queen", "leadership"]],
      [46, ["pushing_upward", "determination", "self_love", "serendipity"]],
      [47, ["oppression", "head_pressure", "realization", "abstract_thinking"]],
      [48, ["the_well", "depth", "talent", "inadequacy"]],
      [49, ["revolution", "necessity", "rejection", "principles"]],
      [50, ["values", "responsibility", "correction", "law"]],
      [51, ["arousing", "shock", "initiation", "competition"]],
      [52, ["stillness", "meditation", "concentration", "keeping_still"]],
      [53, ["development", "gradual_progress", "maturation", "beginnings"]],
      [54, ["ambition", "drive", "marrying_maiden", "relationships"]],
      [55, ["abundance", "spirit", "thunder", "emotional_clarity"]],
      [56, ["stimulation", "travel", "wanderer", "temporary"]],
      [57, ["intuitive_insight", "penetration", "gentle_wind", "clarity"]],
      [58, ["vitality", "joy", "joyous", "encouragement"]],
      [59, ["sexuality", "dispersion", "intimacy", "dissolution"]],
      [60, ["limitation", "acceptance", "restriction", "conservation"]],
      [61, ["inner_truth", "inspiration", "mystery", "pressure"]],
      [62, ["detail", "precision", "small_things", "service"]],
      [63, ["doubt", "after_completion", "transition", "logic"]],
      [64, ["confusion", "before_completion", "not_yet", "potential"]]
    ]);
  }

  private generateSkillsFromCodons(codons: number[]): CodonSkill[] {
    const skills: CodonSkill[] = [];
    
    codons.forEach(codon => {
      const skillNames = this.codonSkillMap.get(codon) || [];
      skillNames.forEach(skillName => {
        skills.push({
          codon,
          name: skillName,
          element: this.getCodonElement(codon),
          proficiency: 0.7 + Math.random() * 0.3, // Random proficiency 0.7-1.0
          activeLines: this.generateActiveLines(codon)
        });
      });
    });
    
    return skills;
  }

  private getCodonElement(codon: number): string {
    // Assign elements based on codon ranges
    if (codon <= 16) return "fire";      // Creative/expressive
    if (codon <= 32) return "earth";     // Practical/grounding  
    if (codon <= 48) return "air";       // Mental/analytical
    return "water";                      // Emotional/intuitive
  }

  private generateActiveLines(codon: number): number[] {
    const numActiveLines = 2 + Math.floor(Math.random() * 3); // 2-4 active lines
    const lines: number[] = [];
    
    while (lines.length < numActiveLines) {
      const line = Math.floor(Math.random() * 6) + 1; // Lines 1-6
      if (!lines.includes(line)) {
        lines.push(line);
      }
    }
    
    return lines.sort();
  }

  private initializeCities(): void {
    // Body District (Tropical Astrology)
    const bodyDistrict: CityDistrict = {
      name: "Soma Plaza",
      type: "Body",
      astrology_system: "tropical",
      agents: [],
      buildings: [
        {
          id: "body-1",
          name: "Action Center",
          type: "workplace",
          level: 1,
          capacity: 10,
          function: "Process physical manifestation tasks",
          location: { x: 100, y: 100 },
          status: "active"
        },
        {
          id: "body-2",
          name: "Kinetic Gardens",
          type: "residential",
          level: 1,
          capacity: 20,
          function: "Agent rest and physical regeneration",
          location: { x: 150, y: 120 },
          status: "active"
        }
      ],
      resources: { energy: 100, focus: 80, creativity: 60 },
      activity_level: 0.7,
      collapse_engine: new ElectronCollapseEngine({
        weights: [1.2, 0.8, 1.0], // Body-focused weighting
        core_threshold: 0.65,
        advisory_threshold: 0.45,
        gate_allow: {
          "1.1": ["creative_expression", "leadership"],
          "8.4": ["contribution", "role_modeling"],
          "9.2": ["focus", "determination"]
        }
      })
    };

    // Mind District (Sidereal Astrology)
    const mindDistrict: CityDistrict = {
      name: "Cerebral Commons",
      type: "Mind",
      astrology_system: "sidereal",
      agents: [],
      buildings: [
        {
          id: "mind-1",
          name: "Analysis Tower",
          type: "workplace",
          level: 1,
          capacity: 15,
          function: "Strategic planning and logical analysis",
          location: { x: 300, y: 100 },
          status: "active"
        },
        {
          id: "mind-2",
          name: "Knowledge Library",
          type: "utility",
          level: 1,
          capacity: 50,
          function: "Information storage and pattern recognition",
          location: { x: 320, y: 80 },
          status: "active"
        }
      ],
      resources: { logic: 100, patterns: 90, systems: 75 },
      activity_level: 0.8,
      collapse_engine: new ElectronCollapseEngine({
        weights: [0.8, 1.2, 1.0], // Mind-focused weighting
        core_threshold: 0.75,
        advisory_threshold: 0.50,
        divergence_lambda: 0.15, // Less penalty for logical disagreement
        gate_allow: {
          "23.3": ["explanation", "insight"],
          "24.1": ["rationalization", "natural_thinking"],
          "31.2": ["influence", "leadership"]
        }
      })
    };

    // Heart District (Draconic Astrology)
    const heartDistrict: CityDistrict = {
      name: "Empathy Enclave",
      type: "Heart",
      astrology_system: "draconic",
      agents: [],
      buildings: [
        {
          id: "heart-1",
          name: "Compassion Circle",
          type: "workplace",
          level: 1,
          capacity: 12,
          function: "Emotional processing and value alignment",
          location: { x: 200, y: 200 },
          status: "active"
        },
        {
          id: "heart-2",
          name: "Wisdom Well",
          type: "spiritual",
          level: 1,
          capacity: 30,
          function: "Soul guidance and authentic expression",
          location: { x: 180, y: 220 },
          status: "active"
        }
      ],
      resources: { compassion: 100, wisdom: 85, authenticity: 90 },
      activity_level: 0.6,
      collapse_engine: new ElectronCollapseEngine({
        weights: [1.0, 0.8, 1.2], // Heart-focused weighting
        core_threshold: 0.60, // More lenient threshold for emotional wisdom
        advisory_threshold: 0.40,
        risk_lambda: 0.25, // Less risk penalty for emotional guidance
        gate_allow: {
          "49.5": ["revolution", "necessity"],
          "55.1": ["abundance", "emotional_clarity"],
          "58.2": ["joy", "vitality"],
          "61.4": ["inner_truth", "inspiration"]
        }
      })
    };

    this.districts.set("body", bodyDistrict);
    this.districts.set("mind", mindDistrict);
    this.districts.set("heart", heartDistrict);

    // Initialize agents in each district
    this.spawnInitialAgents();
  }

  private spawnInitialAgents(): void {
    // Body District Agents (Tropical gates 1-21)
    const bodyAgents = [
      {
        id: "body-agent-1",
        name: "Kai the Kinetic",
        role: "Action Coordinator",
        district: "Body" as const,
        location: { x: 105, y: 105 },
        status: "active" as const,
        activeCodens: [1, 8, 9], // Creative, Contribution, Focus
        skills: this.generateSkillsFromCodons([1, 8, 9]),
        specialization: ["creative_expression", "leadership", "focus", "determination"],
        memory: ["Tropical creative force activating through movement"],
        relationships: {},
        resonance: { color: 1, tone: 3, base: 2 }
      },
      {
        id: "body-agent-2", 
        name: "Terra the Builder",
        role: "Manifestation Specialist",
        district: "Body" as const,
        location: { x: 155, y: 125 },
        status: "idle" as const,
        activeCodens: [2, 5, 10], // Receptive, Waiting, Treading
        skills: this.generateSkillsFromCodons([2, 5, 10]),
        specialization: ["intuition", "timing", "behavior_modification", "life_force"],
        memory: ["Earth energies provide foundation for manifestation"],
        relationships: {},
        resonance: { color: 2, tone: 1, base: 4 }
      }
    ];

    // Mind District Agents (Sidereal gates 22-42)
    const mindAgents = [
      {
        id: "mind-agent-1",
        name: "Sage the Strategist",
        role: "Pattern Analyst",
        district: "Mind" as const,
        location: { x: 305, y: 105 },
        status: "active" as const,
        activeCodens: [23, 24, 31], // Explanation, Return, Influence
        skills: this.generateSkillsFromCodons([23, 24, 31]),
        specialization: ["explanation", "insight", "rationalization", "influence"],
        memory: ["Sidereal patterns reveal deeper analytical truths"],
        relationships: {},
        resonance: { color: 3, tone: 2, base: 1 }
      },
      {
        id: "mind-agent-2",
        name: "Logic the Librarian",
        role: "Knowledge Keeper",
        district: "Mind" as const,
        location: { x: 325, y: 85 },
        status: "busy" as const,
        activeCodens: [26, 29, 32], // Taming Power, Commitment, Endurance
        skills: this.generateSkillsFromCodons([26, 29, 32]),
        specialization: ["accumulated_energy", "commitment", "endurance", "conservation"],
        memory: ["Knowledge requires systematic commitment to endure"],
        relationships: {},
        resonance: { color: 4, tone: 5, base: 3 }
      }
    ];

    // Heart District Agents (Draconic gates 43-64)
    const heartAgents = [
      {
        id: "heart-agent-1",
        name: "Luna the Loving",
        role: "Emotional Guide",
        district: "Heart" as const,
        location: { x: 205, y: 205 },
        status: "active" as const,
        activeCodens: [49, 55, 58], // Revolution, Abundance, Joy
        skills: this.generateSkillsFromCodons([49, 55, 58]),
        specialization: ["revolution", "emotional_clarity", "joy", "vitality"],
        memory: ["Draconic soul energy activates through emotional authenticity"],
        relationships: {},
        resonance: { color: 5, tone: 4, base: 2 }
      },
      {
        id: "heart-agent-2",
        name: "Aria the Authentic",
        role: "Values Counselor", 
        district: "Heart" as const,
        location: { x: 185, y: 225 },
        status: "idle" as const,
        activeCodens: [50, 57, 61], // Values, Intuitive Insight, Inner Truth
        skills: this.generateSkillsFromCodons([50, 57, 61]),
        specialization: ["values", "intuitive_insight", "inner_truth", "inspiration"],
        memory: ["Authentic values emerge through inner truth and clarity"],
        relationships: {},
        resonance: { color: 6, tone: 6, base: 5 }
      }
    ];

    // Add agents to districts and global registry
    bodyAgents.forEach(agent => {
      this.agents.set(agent.id, agent);
      this.districts.get("body")!.agents.push(agent);
    });

    mindAgents.forEach(agent => {
      this.agents.set(agent.id, agent);
      this.districts.get("mind")!.agents.push(agent);
    });

    heartAgents.forEach(agent => {
      this.agents.set(agent.id, agent);
      this.districts.get("heart")!.agents.push(agent);
    });
  }

  async processConsciousnessQuery(question: string, chartData: ChartData): Promise<{
    bodyResponse?: ConsciousnessResponse;
    mindResponse?: ConsciousnessResponse;
    heartResponse?: ConsciousnessResponse;
    cityActivities: Record<string, any>;
  }> {
    // Create tasks for each district
    const bodyTask = this.createTask("consciousness_query", question, "Body");
    const mindTask = this.createTask("consciousness_query", question, "Mind");
    const heartTask = this.createTask("consciousness_query", question, "Heart");

    // Assign agents to tasks
    await this.assignAgentsToTask(bodyTask.id, "body");
    await this.assignAgentsToTask(mindTask.id, "mind");
    await this.assignAgentsToTask(heartTask.id, "heart");

    // Process tasks in parallel
    const [bodyResult, mindResult, heartResult] = await Promise.all([
      this.executeTask(bodyTask.id, chartData),
      this.executeTask(mindTask.id, chartData),
      this.executeTask(heartTask.id, chartData)
    ]);

    // Update city states based on activity
    this.updateCityActivity();

    return {
      bodyResponse: bodyResult,
      mindResponse: mindResult,
      heartResponse: heartResult,
      cityActivities: this.getCityStates()
    };
  }

  private createTask(type: string, question: string, district: "Body" | "Mind" | "Heart"): CityTask {
    const task: CityTask = {
      id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: type as any,
      question,
      assigned_agents: [],
      district,
      priority: 1,
      status: "pending",
      created_at: new Date()
    };

    this.tasks.set(task.id, task);
    return task;
  }

  private async assignAgentsToTask(taskId: string, districtKey: string): Promise<void> {
    const task = this.tasks.get(taskId);
    const district = this.districts.get(districtKey);
    
    if (!task || !district) return;

    // Find available agents in the district
    const availableAgents = district.agents.filter(agent => 
      agent.status === "active" || agent.status === "idle"
    );

    // Assign the most suitable agent
    if (availableAgents.length > 0) {
      const selectedAgent = availableAgents[0];
      task.assigned_agents.push(selectedAgent.id);
      selectedAgent.status = "busy";
      selectedAgent.currentTask = taskId;
    }
  }

  private async executeTask(taskId: string, chartData: ChartData): Promise<ConsciousnessResponse | undefined> {
    const task = this.tasks.get(taskId);
    if (!task || !task.question) return;

    const startTime = Date.now();
    task.status = "in_progress";

    // Get assigned agent
    const agentId = task.assigned_agents[0];
    const agent = this.agents.get(agentId);
    
    if (!agent) return;

    // Simulate agent processing time
    await new Promise(resolve => setTimeout(resolve, 300 + Math.random() * 700));

    // Generate district-specific response
    let response = "";
    let model = "";

    switch (task.district) {
      case "Body":
        model = "tinyllama";
        response = this.generateBodyResponse(task.question, agent, chartData);
        break;
      case "Mind":
        model = "mistral";
        response = this.generateMindResponse(task.question, agent, chartData);
        break;
      case "Heart":
        model = "phi";
        response = this.generateHeartResponse(task.question, agent, chartData);
        break;
    }

    // Update agent memory
    agent.memory.push(`Processed: ${task.question.substring(0, 50)}...`);
    if (agent.memory.length > 10) {
      agent.memory = agent.memory.slice(-10); // Keep last 10 memories
    }

    // Complete task
    task.status = "completed";
    agent.status = "active";
    agent.currentTask = undefined;

    return {
      node: task.district,
      model,
      response,
      confidence: 0.7 + Math.random() * 0.3,
      resonance_factors: this.calculateAgentResonance(agent, chartData),
      processing_time_ms: Date.now() - startTime
    };
  }

  private generateMBHResponses(question: string, agent: CityAgent, chartData: ChartData): Record<string, any> {
    return {
      Body: this.generateBodyResponse(question, agent, chartData),
      Mind: this.generateMindResponse(question, agent, chartData),
      Heart: this.generateHeartResponse(question, agent, chartData)
    };
  }

  private generateFieldSignature(agent: CityAgent, chartData: ChartData): any {
    // Use the agent's primary active gate as the field signature
    const primaryGate = agent.activeGates[0] || 1;
    const lines = agent.gateLines.get(primaryGate) || [1];
    const primaryLine = lines[0] || 1;
    
    return {
      gate_line: `${primaryGate}.${primaryLine}`,
      color: agent.colorToneBase.color,
      tone: agent.colorToneBase.tone,
      base: agent.colorToneBase.base,
      sign: "Cosmic",
      house: "District",
      axis: "Consciousness"
    };
  }

  private formatBodyResponse(collapseResult: any, agent: CityAgent, question: string): string {
    const skills = agent.skills.slice(0, 2).join(", ");
    return `[Soma Plaza | Gate ${collapseResult.audit?.field_gate || "1.1"}] ${agent.name} channels kinetic wisdom through ${skills}. ${collapseResult.field_sentence}. Raw manifestation power through tropical astrology guides this response: ${collapseResult.chosen?.text || "Action must arise from embodied knowing."} (Score: ${Math.round(collapseResult.score * 100)}%)`;
  }

  private formatMindResponse(collapseResult: any, agent: CityAgent, question: string): string {
    const skills = agent.skills.slice(0, 2).join(", ");  
    return `[Cerebral Commons | Gate ${collapseResult.audit?.field_gate || "23.3"}] ${agent.name} processes through ${skills} using sidereal precision. ${collapseResult.field_sentence}. Logical analysis reveals: ${collapseResult.chosen?.text || "Understanding emerges from systematic inquiry."} (Score: ${Math.round(collapseResult.score * 100)}%)`;
  }

  private formatHeartResponse(collapseResult: any, agent: CityAgent, question: string): string {
    const skills = agent.skills.slice(0, 2).join(", ");
    return `[Empathy Enclave | Gate ${collapseResult.audit?.field_gate || "49.5"}] ${agent.name} feels through ${skills} with draconic soul-sight. ${collapseResult.field_sentence}. Heart wisdom whispers: ${collapseResult.chosen?.text || "Authentic connection illuminates all paths."} (Score: ${Math.round(collapseResult.score * 100)}%)`;
  }

  private generateBodyResponse(question: string, agent: CityAgent, chartData: ChartData): string {
    const q = question.toLowerCase();
    const agentStyle = agent.specialization.includes("movement") ? "kinetic" : "grounding";
    
    if (q.includes('focus') || q.includes('week')) {
      return `${agent.name} from Soma Plaza advises: Your tropical chart activates Mars energy this week. I recommend starting with physical movement - even 10 minutes of intentional exercise will unlock your creative flow. The body knows what the mind hasn't figured out yet.`;
    }
    if (q.includes('purpose') || q.includes('meaning')) {
      return `${agent.name} speaks from the Action Center: Purpose lives in your hands, not your head. Your tropical Sun placement shows meaning emerges through doing. What physical creation calls to you? Build something, move something, heal something. Your purpose reveals itself through embodied action.`;
    }
    return `${agent.name} channels Soma Plaza wisdom: Trust your physical instincts right now. The tropical energies flowing through our district favor concrete action over abstract planning. What can you do today that moves you closer to embodied alignment?`;
  }

  private generateMindResponse(question: string, agent: CityAgent, chartData: ChartData): string {
    const q = question.toLowerCase();
    const agentStyle = agent.specialization.includes("analysis") ? "analytical" : "systematic";
    
    if (q.includes('focus') || q.includes('week')) {
      return `${agent.name} from Cerebral Commons reports: Analysis of your sidereal placements reveals optimal timing for systematic progress. Break complex projects into logical phases this week. Our Analysis Tower processes suggest creating frameworks and clear decision trees.`;
    }
    if (q.includes('purpose') || q.includes('meaning')) {
      return `${agent.name} accessing Knowledge Library data: Your purpose emerges through solving complex problems others cannot. The sidereal Mercury position indicates you find meaning by organizing chaos into understandable systems. What patterns need your unique analytical gifts?`;
    }
    return `${agent.name} transmits from Cerebral Commons: The current sidereal configuration favors strategic thinking over reactive responses. What systems can you design or improve that will serve your long-term objectives?`;
  }

  private generateHeartResponse(question: string, agent: CityAgent, chartData: ChartData): string {
    const q = question.toLowerCase();
    const agentStyle = agent.specialization.includes("empathy") ? "compassionate" : "authentic";
    
    if (q.includes('focus') || q.includes('week')) {
      return `${agent.name} whispers from Empathy Enclave: Your draconic Moon stirs with deep currents this week. Focus on what truly feeds your soul, not what you think you should want. The Compassion Circle reminds us that authentic priorities always bring peace.`;
    }
    if (q.includes('purpose') || q.includes('meaning')) {
      return `${agent.name} channels wisdom from the Well: Your soul's purpose shines brightest when you honor what makes you genuinely happy. The draconic chart reveals your authentic self beyond societal masks. Trust what brings you alive - that path holds your deepest gifts.`;
    }
    return `${agent.name} speaks from Empathy Enclave: The draconic energies flowing through our district call for authentic expression. What would you choose if you trusted your heart completely? That direction holds your wisdom.`;
  }

  private calculateAgentResonance(agent: CityAgent, chartData: ChartData): Record<string, number> {
    const factors: Record<string, number> = {};
    
    // Agent specialization resonance
    agent.specialization.forEach(spec => {
      factors[`agent_${spec}`] = 0.8 + Math.random() * 0.2;
    });
    
    // District-specific chart resonance
    const districtGates = chartData.gates.filter(gate => {
      switch (agent.district) {
        case "Body": return gate.type === "tropical";
        case "Mind": return gate.type === "sidereal"; 
        case "Heart": return gate.type === "draconic";
        default: return false;
      }
    });
    
    factors.chart_alignment = districtGates.length > 0 ? 0.7 + (districtGates.length * 0.05) : 0.5;
    
    return factors;
  }

  private updateCityActivity(): void {
    this.districts.forEach(district => {
      const activeAgents = district.agents.filter(a => a.status === "busy").length;
      const totalAgents = district.agents.length;
      district.activity_level = totalAgents > 0 ? activeAgents / totalAgents : 0;
      
      // Update resources based on activity
      Object.keys(district.resources).forEach(resource => {
        district.resources[resource] = Math.max(0, 
          district.resources[resource] + (district.activity_level * 5) - 2
        );
      });
    });
  }

  getCityStates(): Record<string, any> {
    const states: Record<string, any> = {};
    
    this.districts.forEach((district, key) => {
      states[key] = {
        name: district.name,
        type: district.type,
        astrology_system: district.astrology_system,
        activity_level: district.activity_level,
        resources: district.resources,
        agent_count: district.agents.length,
        active_agents: district.agents.filter(a => a.status === "active" || a.status === "busy").length,
        buildings: district.buildings.length,
        recent_memories: district.agents.flatMap(agent => 
          agent.memory.slice(-2).map(memory => ({
            agent: agent.name,
            memory
          }))
        )
      };
    });
    
    return states;
  }

  getDistrictInfo(districtType: "Body" | "Mind" | "Heart"): CityDistrict | undefined {
    const key = districtType.toLowerCase();
    return this.districts.get(key);
  }

  getAllAgents(): CityAgent[] {
    return Array.from(this.agents.values());
  }
}