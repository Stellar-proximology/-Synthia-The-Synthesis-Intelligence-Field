// Human Design and Astrological Mathematics
// Based on SharpAstrology.HumanDesign and HDKit principles

interface PlanetPosition {
  longitude: number; // degrees
  latitude: number;  // degrees
  distance: number;  // AU
}

interface HumanDesignActivation {
  gate: number;     // 1-64
  line: number;     // 1-6
  color: number;    // 1-6
  tone: number;     // 1-6
  base: number;     // 1-6
  degree: number;   // exact degree position
  minute: number;   // minute component
  second: number;   // second component
  zodiacSign: string;
  house: number;    // 1-12
  axis: 'tropical' | 'sidereal' | 'draconic';
}

// Gate positions in degrees (tropical zodiac)
const GATE_POSITIONS: Record<number, { start: number; end: number; sign: string }> = {
  41: { start: 0.0, end: 5.625, sign: "Aries" },      // The Decrease
  19: { start: 5.625, end: 11.25, sign: "Aries" },    // Approach
  13: { start: 11.25, end: 16.875, sign: "Aries" },   // Fellowship
  49: { start: 16.875, end: 22.5, sign: "Aries" },    // Revolution
  30: { start: 22.5, end: 28.125, sign: "Aries" },    // Clinging Fire
  55: { start: 28.125, end: 30.0, sign: "Aries" },    // Abundance
  // Continue for all 64 gates...
  // Taurus starts at 30°
  37: { start: 30.0, end: 35.625, sign: "Taurus" },
  63: { start: 35.625, end: 41.25, sign: "Taurus" },
  22: { start: 41.25, end: 46.875, sign: "Taurus" },
  36: { start: 46.875, end: 52.5, sign: "Taurus" },
  25: { start: 52.5, end: 58.125, sign: "Taurus" },
  17: { start: 58.125, end: 60.0, sign: "Taurus" },
  // ... continue for all signs and gates
};

// Complete gate order following the I Ching wheel
const GATE_ORDER = [41, 19, 13, 49, 30, 55, 37, 63, 22, 36, 25, 17, 21, 51, 42, 3, 27, 24, 2, 23, 8, 20, 16, 35, 45, 12, 15, 52, 39, 53, 62, 56, 31, 33, 7, 4, 29, 59, 40, 64, 47, 6, 46, 18, 48, 57, 32, 50, 28, 44, 1, 43, 14, 34, 9, 5, 26, 11, 10, 58, 38, 54, 61, 60];

export class AstrologyMath {
  
  // Convert longitude to gate/line/color/tone/base
  static longitudeToActivation(longitude: number, axis: 'tropical' | 'sidereal' | 'draconic' = 'tropical'): HumanDesignActivation {
    // Adjust for coordinate system
    let adjustedLong = longitude;
    if (axis === 'sidereal') {
      // Subtract ayanamsa (approximately 24° for 2024)
      adjustedLong = this.normalizeAngle(longitude - 24.1);
    } else if (axis === 'draconic') {
      // Draconic system starts from true lunar node
      // This is a simplified calculation - real draconic needs lunar node position
      adjustedLong = this.normalizeAngle(longitude + 180);
    }
    
    // Each gate covers 5.625 degrees (360° / 64 gates)
    const gateSize = 360 / 64;
    const gateIndex = Math.floor(adjustedLong / gateSize);
    const gate = GATE_ORDER[gateIndex] || 1;
    
    // Position within the gate (0-5.625°)
    const positionInGate = adjustedLong % gateSize;
    
    // Lines: each gate has 6 lines (5.625° / 6 = 0.9375° per line)
    const lineSize = gateSize / 6;
    const line = Math.floor(positionInGate / lineSize) + 1;
    
    // Position within line for color/tone/base
    const positionInLine = positionInGate % lineSize;
    
    // Colors: 6 colors per line (0.15625° per color)
    const colorSize = lineSize / 6;
    const color = Math.floor(positionInLine / colorSize) + 1;
    
    // Position within color for tone/base
    const positionInColor = positionInLine % colorSize;
    
    // Tones: 6 tones per color
    const toneSize = colorSize / 6;
    const tone = Math.floor(positionInColor / toneSize) + 1;
    
    // Position within tone for base
    const positionInTone = positionInColor % toneSize;
    
    // Bases: 6 bases per tone
    const baseSize = toneSize / 6;
    const base = Math.floor(positionInTone / baseSize) + 1;
    
    // Calculate exact degree/minute/second
    const degree = Math.floor(adjustedLong);
    const minuteDecimal = (adjustedLong - degree) * 60;
    const minute = Math.floor(minuteDecimal);
    const second = Math.floor((minuteDecimal - minute) * 60);
    
    // Determine zodiac sign
    const zodiacSign = this.getZodiacSign(adjustedLong);
    
    // Calculate house (simplified - real calculation needs birth time/location)
    const house = Math.floor(adjustedLong / 30) + 1;
    
    return {
      gate,
      line: Math.max(1, Math.min(6, line)),
      color: Math.max(1, Math.min(6, color)),
      tone: Math.max(1, Math.min(6, tone)),
      base: Math.max(1, Math.min(6, base)),
      degree,
      minute,
      second,
      zodiacSign,
      house,
      axis
    };
  }
  
  // Calculate design date (88 days before birth)
  static calculateDesignDate(birthDate: Date): Date {
    const designDate = new Date(birthDate);
    designDate.setDate(designDate.getDate() - 88);
    return designDate;
  }
  
  // Simplified planetary position calculation
  // In production, this would use Swiss Ephemeris or similar
  static calculatePlanetPosition(planet: string, date: Date): PlanetPosition {
    const julianDay = this.dateToJulianDay(date);
    
    // Simplified orbital calculations (real implementation would use VSOP87 or Swiss Ephemeris)
    switch (planet.toLowerCase()) {
      case 'sun':
        return this.calculateSunPosition(julianDay);
      case 'moon':
        return this.calculateMoonPosition(julianDay);
      case 'mercury':
        return this.calculateMercuryPosition(julianDay);
      case 'venus':
        return this.calculateVenusPosition(julianDay);
      case 'mars':
        return this.calculateMarsPosition(julianDay);
      case 'jupiter':
        return this.calculateJupiterPosition(julianDay);
      case 'saturn':
        return this.calculateSaturnPosition(julianDay);
      case 'uranus':
        return this.calculateUranusPosition(julianDay);
      case 'neptune':
        return this.calculateNeptunePosition(julianDay);
      case 'pluto':
        return this.calculatePlutoPosition(julianDay);
      case 'north_node':
        return this.calculateNorthNodePosition(julianDay);
      case 'south_node':
        const northNode = this.calculateNorthNodePosition(julianDay);
        return {
          longitude: this.normalizeAngle(northNode.longitude + 180),
          latitude: -northNode.latitude,
          distance: northNode.distance
        };
      default:
        return { longitude: 0, latitude: 0, distance: 1 };
    }
  }
  
  // Helper methods
  private static normalizeAngle(angle: number): number {
    while (angle < 0) angle += 360;
    while (angle >= 360) angle -= 360;
    return angle;
  }
  
  private static getZodiacSign(longitude: number): string {
    const signs = ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 
                   'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'];
    return signs[Math.floor(longitude / 30)];
  }
  
  private static dateToJulianDay(date: Date): number {
    // Convert JavaScript Date to Julian Day Number
    const year = date.getUTCFullYear();
    const month = date.getUTCMonth() + 1;
    const day = date.getUTCDate();
    const hour = date.getUTCHours();
    const minute = date.getUTCMinutes();
    const second = date.getUTCSeconds();
    
    const a = Math.floor((14 - month) / 12);
    const y = year + 4800 - a;
    const m = month + 12 * a - 3;
    
    const jdn = day + Math.floor((153 * m + 2) / 5) + 365 * y + Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) - 32045;
    const jd = jdn + (hour - 12) / 24 + minute / 1440 + second / 86400;
    
    return jd;
  }
  
  // Simplified planetary position calculations
  // These are approximations - real calculations require full orbital mechanics
  
  private static calculateSunPosition(julianDay: number): PlanetPosition {
    const T = (julianDay - 2451545.0) / 36525.0;
    const L0 = 280.46646 + 36000.76983 * T + 0.0003032 * T * T;
    const M = 357.52911 + 35999.05029 * T - 0.0001537 * T * T;
    const e = 0.016708634 - 0.000042037 * T - 0.0000001267 * T * T;
    
    const C = (1.914602 - 0.004817 * T - 0.000014 * T * T) * Math.sin(this.deg2rad(M)) +
              (0.019993 - 0.000101 * T) * Math.sin(this.deg2rad(2 * M)) +
              0.000289 * Math.sin(this.deg2rad(3 * M));
    
    const longitude = this.normalizeAngle(L0 + C);
    
    return {
      longitude,
      latitude: 0, // Sun's latitude is always 0 by definition
      distance: 1.000001018 * (1 - e * e) / (1 + e * Math.cos(this.deg2rad(M + C)))
    };
  }
  
  private static calculateMoonPosition(julianDay: number): PlanetPosition {
    const T = (julianDay - 2451545.0) / 36525.0;
    const L = 218.3164477 + 481267.88123421 * T - 0.0015786 * T * T;
    const D = 297.8501921 + 445267.1114034 * T - 0.0018819 * T * T;
    const M = 357.5291092 + 35999.0502909 * T - 0.0001536 * T * T;
    const Mp = 134.9633964 + 477198.8675055 * T + 0.0087414 * T * T;
    const F = 93.272095 + 483202.0175233 * T - 0.0036539 * T * T;
    
    // Simplified lunar longitude calculation
    const longitude = this.normalizeAngle(L + 6.289 * Math.sin(this.deg2rad(Mp)));
    const latitude = 5.128 * Math.sin(this.deg2rad(F));
    
    return {
      longitude,
      latitude,
      distance: 385000 // km, approximate
    };
  }
  
  // Simplified calculations for other planets
  // In production, use full VSOP87 or Swiss Ephemeris calculations
  
  private static calculateMercuryPosition(julianDay: number): PlanetPosition {
    const T = (julianDay - 2451545.0) / 36525.0;
    const L = 252.250906 + 149472.674635 * T;
    return { longitude: this.normalizeAngle(L), latitude: 0, distance: 0.39 };
  }
  
  private static calculateVenusPosition(julianDay: number): PlanetPosition {
    const T = (julianDay - 2451545.0) / 36525.0;
    const L = 181.979801 + 58517.816727 * T;
    return { longitude: this.normalizeAngle(L), latitude: 0, distance: 0.72 };
  }
  
  private static calculateMarsPosition(julianDay: number): PlanetPosition {
    const T = (julianDay - 2451545.0) / 36525.0;
    const L = 355.433275 + 19140.299314 * T;
    return { longitude: this.normalizeAngle(L), latitude: 0, distance: 1.52 };
  }
  
  private static calculateJupiterPosition(julianDay: number): PlanetPosition {
    const T = (julianDay - 2451545.0) / 36525.0;
    const L = 34.351484 + 3034.905665 * T;
    return { longitude: this.normalizeAngle(L), latitude: 0, distance: 5.20 };
  }
  
  private static calculateSaturnPosition(julianDay: number): PlanetPosition {
    const T = (julianDay - 2451545.0) / 36525.0;
    const L = 50.077471 + 1222.113669 * T;
    return { longitude: this.normalizeAngle(L), latitude: 0, distance: 9.54 };
  }
  
  private static calculateUranusPosition(julianDay: number): PlanetPosition {
    const T = (julianDay - 2451545.0) / 36525.0;
    const L = 314.055005 + 428.466669 * T;
    return { longitude: this.normalizeAngle(L), latitude: 0, distance: 19.19 };
  }
  
  private static calculateNeptunePosition(julianDay: number): PlanetPosition {
    const T = (julianDay - 2451545.0) / 36525.0;
    const L = 304.348665 + 218.486200 * T;
    return { longitude: this.normalizeAngle(L), latitude: 0, distance: 30.06 };
  }
  
  private static calculatePlutoPosition(julianDay: number): PlanetPosition {
    const T = (julianDay - 2451545.0) / 36525.0;
    const L = 238.958116 + 145.18042 * T;
    return { longitude: this.normalizeAngle(L), latitude: 0, distance: 39.44 };
  }
  
  private static calculateNorthNodePosition(julianDay: number): PlanetPosition {
    const T = (julianDay - 2451545.0) / 36525.0;
    const L = 125.044522 - 1934.136261 * T;
    return { longitude: this.normalizeAngle(L), latitude: 0, distance: 1 };
  }
  
  private static deg2rad(degrees: number): number {
    return degrees * Math.PI / 180;
  }
  
  private static rad2deg(radians: number): number {
    return radians * 180 / Math.PI;
  }
}