// electron_collapse.ts
// Cynthia — Electron Collapse Logic (MBH → single decision)
// TypeScript port of the Python collapse engine

interface Candidate {
  id: string;
  kind: "API" | "ADVICE" | "DEFER";
  text: string;
  api_call?: string;
  body_score?: number;
  mind_score?: number;
  heart_score?: number;
  risks: Array<{ desc: string; severity: number }>;
  tags: string[];
  source: string;
}

interface CollapseConfig {
  weights: [number, number, number]; // [Body, Mind, Heart]
  core_threshold: number;
  advisory_threshold: number;
  divergence_lambda: number;
  risk_lambda: number;
  forbidden_tag_pairs: Array<[string, string]>;
  gate_allow: Record<string, string[]>;
}

interface FieldSignature {
  gate_line: string;
  color?: number;
  tone?: number;
  base?: number;
  degree?: string;
  sign?: string;
  house?: string;
  axis?: string;
}

interface CollapseResult {
  orbital: "CORE_ACTION" | "ADVISORY" | "DEFER";
  chosen?: Candidate;
  score: number;
  field_sentence: string;
  audit: Record<string, any>;
}

export class ElectronCollapseEngine {
  private config: CollapseConfig;

  constructor(config?: Partial<CollapseConfig>) {
    this.config = {
      weights: [1.0, 1.0, 1.0],
      core_threshold: 0.70,
      advisory_threshold: 0.50,
      divergence_lambda: 0.20,
      risk_lambda: 0.35,
      forbidden_tag_pairs: [
        ["do_nothing", "execute_payment"],
        ["delay", "urgent"]
      ],
      gate_allow: {},
      ...config
    };
  }

  private safe01(x?: number, defaultVal: number = 0.5): number {
    if (x === undefined || x === null) return defaultVal;
    return Math.max(0.0, Math.min(1.0, x));
  }

  private extractActionAndApi(text: string): [string | null, string | null] {
    const actionMatch = text.match(/\bACTION\s*:\s*(.+)/i);
    const plan = actionMatch ? actionMatch[1].trim() : null;
    
    const apiMatch = text.match(/\b(?:apis?\.)?[a-z_]+\.[a-z_]+\(.+\)/i);
    const api = apiMatch ? apiMatch[0].trim() : null;
    
    return [plan, api];
  }

  private heuristicScores(text: string): [number, number, number] {
    const t = text.toLowerCase();
    const body = 0.5 + 0.25 * (t.includes("action:") || t.includes("api") || t.includes("execute") ? 1 : 0);
    const mind = 0.5 + 0.2 * (t.includes("because") || t.includes("logic") || t.includes("plan") ? 1 : 0);
    const heart = 0.5 + 0.2 * (t.includes("feel") || t.includes("risk") || t.includes("relationship") || t.includes("impact") ? 1 : 0);
    return [this.safe01(body), this.safe01(mind), this.safe01(heart)];
  }

  private divergencePenalty(cands: Candidate[], weights: [number, number, number]): number {
    if (cands.length === 0) return 0.0;
    
    const vecs = cands.map(c => [
      this.safe01(c.body_score),
      this.safe01(c.mind_score),
      this.safe01(c.heart_score)
    ]);

    const bs = vecs.map(v => v[0]);
    const ms = vecs.map(v => v[1]);
    const hs = vecs.map(v => v[2]);

    const pstdev = (arr: number[]) => {
      if (arr.length <= 1) return 0;
      const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
      const variance = arr.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / arr.length;
      return Math.sqrt(variance);
    };

    return pstdev(bs) * weights[0] + pstdev(ms) * weights[1] + pstdev(hs) * weights[2];
  }

  private riskPenalty(c: Candidate): number {
    if (c.risks.length === 0) return 0.0;
    const meanRisk = c.risks.reduce((sum, r) => sum + Math.max(0, Math.min(1, r.severity)), 0) / c.risks.length;
    return this.config.risk_lambda * meanRisk;
  }

  private pauliExclusion(c: Candidate, others: Candidate[]): boolean {
    const tags = new Set(c.tags);
    for (const other of others) {
      if (other.id === c.id) continue;
      const otherTags = new Set(other.tags);
      
      for (const [a, b] of this.config.forbidden_tag_pairs) {
        if ((tags.has(a) && otherTags.has(b)) || (tags.has(b) && otherTags.has(a))) {
          return true;
        }
      }
    }
    return false;
  }

  private extractCandidatesFromMBH(mbh: Record<string, any>): Candidate[] {
    const candidates: Candidate[] = [];

    const addCandidate = (kind: string, text: string, source: string, scores?: [number, number, number]) => {
      const [plan, api] = this.extractActionAndApi(text);
      const [b, m, h] = scores || this.heuristicScores(text);
      
      const tags: string[] = [];
      if (api) tags.push("execute_api");
      if (text.toLowerCase().includes("urgent")) tags.push("urgent");
      if (text.toLowerCase().includes("delay")) tags.push("delay");
      if (text.toLowerCase().includes("do nothing") || text.toLowerCase().includes("observe")) {
        tags.push("do_nothing");
      }

      candidates.push({
        id: Math.random().toString(36).substring(2, 10),
        kind: kind as any,
        text: plan || text,
        api_call: api || undefined,
        body_score: b,
        mind_score: m,
        heart_score: h,
        risks: [],
        tags,
        source
      });
    };

    for (const node of ["Body", "Mind", "Heart"]) {
      const v = mbh[node];
      if (!v) continue;

      if (typeof v === "object" && v.proposals) {
        for (const p of v.proposals) {
          addCandidate(
            p.kind || "ADVICE",
            p.text || "",
            node,
            [this.safe01(p.body_score), this.safe01(p.mind_score), this.safe01(p.heart_score)]
          );
        }
      } else if (typeof v === "string") {
        const isApi = v.toLowerCase().includes("action:") || /\b(?:apis?\.)?[a-z_]+\.[a-z_]+\(.+\)/i.test(v);
        addCandidate(isApi ? "API" : "ADVICE", v, node);
      }
    }

    return candidates;
  }

  private scoreCandidate(c: Candidate, divergence: number, allowTags?: string[]): number {
    const b = this.safe01(c.body_score);
    const m = this.safe01(c.mind_score);  
    const h = this.safe01(c.heart_score);
    
    const base = this.config.weights[0] * b + this.config.weights[1] * m + this.config.weights[2] * h;
    const riskPen = this.riskPenalty(c);
    
    let allowBoost = 1.0;
    if (allowTags && allowTags.length > 0) {
      const hasAllowedTag = c.tags.some(tag => allowTags.includes(tag));
      if (!hasAllowedTag) {
        allowBoost = 0.90;
      }
    }

    const score = (base - riskPen - this.config.divergence_lambda * divergence) * allowBoost;
    return Math.max(0.0, Math.min(1.0, score));
  }

  private chooseOrbital(score: number): "CORE_ACTION" | "ADVISORY" | "DEFER" {
    if (score >= this.config.core_threshold) return "CORE_ACTION";
    if (score >= this.config.advisory_threshold) return "ADVISORY";
    return "DEFER";
  }

  private buildFieldSentence(sig: FieldSignature, chosen?: Candidate, orbital?: string): string {
    const gl = sig.gate_line || "00.0";
    const ctb = `${sig.color || 0}.${sig.tone || 0}.${sig.base || 0}`;
    const deg = sig.degree || "00° 00′ 00″";
    const sign = sig.sign || "—";
    const house = sig.house ? `H${sig.house}` : "H?";
    const axis = sig.axis || "Axis?";
    const actionPart = chosen ? (chosen.api_call || chosen.text) : "observe and log";
    
    return `[${orbital}] [${gl} | CTB ${ctb} | ${sign} ${deg} ${house} ${axis}] → ${actionPart}`;
  }

  collapse(mbh: Record<string, any>, field: FieldSignature): CollapseResult {
    const candidates = this.extractCandidatesFromMBH(mbh);
    const divergence = this.divergencePenalty(candidates, this.config.weights);
    const allowTags = this.config.gate_allow[field.gate_line];

    // Filter by Pauli exclusion
    const filtered = candidates.filter(c => {
      if (!this.pauliExclusion(c, candidates)) return true;
      
      // Keep the stronger one among conflicting candidates
      const cBase = [c.body_score, c.mind_score, c.heart_score]
        .map(s => this.safe01(s))
        .reduce((sum, s) => sum + s, 0) / 3;
      
      for (const other of candidates) {
        if (other.id === c.id) continue;
        if (this.pauliExclusion(c, [other])) {
          const otherBase = [other.body_score, other.mind_score, other.heart_score]
            .map(s => this.safe01(s))
            .reduce((sum, s) => sum + s, 0) / 3;
          if (otherBase > cBase) return false;
        }
      }
      return true;
    });

    // Score and sort
    const scored = filtered.map(c => ({
      candidate: c,
      score: this.scoreCandidate(c, divergence, allowTags)
    })).sort((a, b) => b.score - a.score);

    const chosen = scored.length > 0 ? scored[0].candidate : undefined;
    const bestScore = scored.length > 0 ? scored[0].score : 0.0;
    const orbital = this.chooseOrbital(bestScore);

    // Convert API to ADVICE if orbital is ADVISORY
    let finalChosen = chosen;
    if (orbital === "ADVISORY" && chosen && chosen.kind === "API") {
      finalChosen = {
        ...chosen,
        kind: "ADVICE",
        text: `Consider: ${chosen.text}`,
        api_call: undefined,
        tags: [...chosen.tags, "advisory"]
      };
    }

    const sentence = this.buildFieldSentence(field, finalChosen, orbital);

    const audit = {
      timestamp: Date.now(),
      inputs: mbh,
      candidates_initial: candidates.length,
      candidates_filtered: filtered.length,
      divergence,
      weights: this.config.weights,
      thresholds: {
        core: this.config.core_threshold,
        advisory: this.config.advisory_threshold
      },
      scored_count: scored.length,
      best_score: bestScore
    };

    return {
      orbital,
      chosen: finalChosen,
      score: bestScore,
      field_sentence: sentence,
      audit
    };
  }
}