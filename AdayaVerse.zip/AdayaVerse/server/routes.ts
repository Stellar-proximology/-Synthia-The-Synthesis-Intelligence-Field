import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ConsciousnessService } from "./services/consciousness";
import { askConsciousnessSchema, birthDataSchema } from "@shared/schema";
import { ZodError } from "zod";

// Initialize consciousness service
const consciousnessService = new ConsciousnessService({
  ollama: {
    baseUrl: process.env.OLLAMA_BASE_URL || 'http://localhost:11434',
    models: {
      body: process.env.OLLAMA_BODY_MODEL || 'tinyllama',
      mind: process.env.OLLAMA_MIND_MODEL || 'mistral',
      heart: process.env.OLLAMA_HEART_MODEL || 'phi'
    },
    timeout: parseInt(process.env.OLLAMA_TIMEOUT || '30000')
  },
  collapse: {
    relevance: parseFloat(process.env.COLLAPSE_RELEVANCE || '0.25'),
    coherence: parseFloat(process.env.COLLAPSE_COHERENCE || '0.20'),
    resonance: parseFloat(process.env.COLLAPSE_RESONANCE || '0.25'),
    safety: parseFloat(process.env.COLLAPSE_SAFETY || '0.15'),
    confidence: parseFloat(process.env.COLLAPSE_CONFIDENCE || '0.15')
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint
  app.get("/api/health", async (_req, res) => {
    try {
      const healthStatus = await consciousnessService.healthCheck();
      const overallHealth = Object.values(healthStatus).every(status => status);
      
      res.status(overallHealth ? 200 : 503).json({
        status: overallHealth ? 'healthy' : 'degraded',
        services: healthStatus,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({
        status: 'error',
        message: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      });
    }
  });

  // Calculate astrological chart
  app.post("/api/chart", async (req, res) => {
    try {
      const birthData = birthDataSchema.parse(req.body);
      const chartData = await consciousnessService.calculateChart(birthData);
      
      // Create or update session
      let session;
      if (req.body.session_id) {
        session = await storage.updateSessionChart(req.body.session_id, chartData);
        if (!session) {
          // Session doesn't exist, create new one
          session = await storage.createSession({ birth_data: birthData, chart_data: chartData });
        }
      } else {
        session = await storage.createSession({ birth_data: birthData, chart_data: chartData });
      }
      
      res.json({
        session_id: session.id,
        chart_data: chartData,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({
          error: 'validation_error',
          details: error.errors,
          message: 'Invalid birth data provided'
        });
      } else {
        console.error('Chart calculation error:', error);
        res.status(500).json({
          error: 'calculation_error',
          message: error instanceof Error ? error.message : 'Chart calculation failed'
        });
      }
    }
  });

  // City management endpoints
  app.get('/api/cities', async (req, res) => {
    try {
      const cityStates = consciousnessService.getCityStates();
      res.json(cityStates);
    } catch (error) {
      console.error('Cities API error:', error);
      res.status(500).json({ error: 'Failed to retrieve city states' });
    }
  });

  app.get('/api/cities/agents', async (req, res) => {
    try {
      const agents = consciousnessService.getAllAgents();
      res.json(agents);
    } catch (error) {
      console.error('Agents API error:', error);
      res.status(500).json({ error: 'Failed to retrieve agents' });
    }
  });

  // Ask consciousness question
  app.post("/api/ask", async (req, res) => {
    try {
      const request = askConsciousnessSchema.parse(req.body);
      
      let session;
      let chartData;

      if (request.session_id) {
        // Use existing session
        session = await storage.getSession(request.session_id);
        if (!session) {
          return res.status(404).json({
            error: 'session_not_found',
            message: 'Session not found. Please create a new session with birth data.'
          });
        }
        chartData = session.chart_data;
      } else if (request.birth_data) {
        // Create new session with birth data
        chartData = await consciousnessService.calculateChart(request.birth_data);
        session = await storage.createSession({ 
          birth_data: request.birth_data, 
          chart_data: chartData 
        });
      } else {
        return res.status(400).json({
          error: 'missing_data',
          message: 'Either session_id or birth_data is required'
        });
      }

      // Process the question through consciousness nodes
      const result = await consciousnessService.processQuestion(request.question, chartData);

      // Log the interaction
      const log = await storage.createConsciousnessLog({
        session_id: session.id,
        question: request.question,
        body_response: result.responses.body || null,
        mind_response: result.responses.mind || null,
        heart_response: result.responses.heart || null,
        collapse_result: result.collapse
      });

      res.json({
        session_id: session.id,
        log_id: log.id,
        question: request.question,
        winner: result.collapse.winner,
        final_response: result.collapse.final_response,
        scores: result.collapse.scores,
        reasoning: result.collapse.reasoning,
        all_responses: {
          body: result.responses.body?.response,
          mind: result.responses.mind?.response,
          heart: result.responses.heart?.response
        },
        processing_time_ms: result.collapse.processing_time_ms,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({
          error: 'validation_error',
          details: error.errors,
          message: 'Invalid request data'
        });
      } else {
        console.error('Consciousness processing error:', error);
        res.status(500).json({
          error: 'processing_error',
          message: error instanceof Error ? error.message : 'Failed to process consciousness question'
        });
      }
    }
  });

  // Get session details
  app.get("/api/session/:id", async (req, res) => {
    try {
      const session = await storage.getSession(req.params.id);
      if (!session) {
        return res.status(404).json({
          error: 'session_not_found',
          message: 'Session not found'
        });
      }

      const logs = await storage.getConsciousnessLogs(session.id);

      res.json({
        session,
        logs: logs.map(log => ({
          id: log.id,
          question: log.question,
          winner: log.collapse_result.winner,
          final_response: log.collapse_result.final_response,
          scores: log.collapse_result.scores,
          created_at: log.created_at
        }))
      });
    } catch (error) {
      console.error('Session retrieval error:', error);
      res.status(500).json({
        error: 'retrieval_error',
        message: 'Failed to retrieve session'
      });
    }
  });

  // Get detailed log
  app.get("/api/log/:id", async (req, res) => {
    try {
      const log = await storage.getConsciousnessLog(req.params.id);
      if (!log) {
        return res.status(404).json({
          error: 'log_not_found',
          message: 'Log not found'
        });
      }

      res.json(log);
    } catch (error) {
      console.error('Log retrieval error:', error);
      res.status(500).json({
        error: 'retrieval_error',
        message: 'Failed to retrieve log'
      });
    }
  });

  // Get recent activity (for dashboard)
  app.get("/api/recent", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const logs = await storage.getRecentLogs(limit);

      res.json({
        logs: logs.map(log => ({
          id: log.id,
          session_id: log.session_id,
          question: log.question.substring(0, 100) + (log.question.length > 100 ? '...' : ''),
          winner: log.collapse_result.winner,
          final_response: log.collapse_result.final_response.substring(0, 200) + 
                         (log.collapse_result.final_response.length > 200 ? '...' : ''),
          scores: log.collapse_result.scores,
          created_at: log.created_at
        })),
        total: logs.length
      });
    } catch (error) {
      console.error('Recent logs retrieval error:', error);
      res.status(500).json({
        error: 'retrieval_error',
        message: 'Failed to retrieve recent activity'
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
