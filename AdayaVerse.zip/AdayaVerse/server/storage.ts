import { type Session, type ConsciousnessLog, type InsertSession, type InsertConsciousnessLog, type BirthData, type ChartData } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Session management
  createSession(session: InsertSession): Promise<Session>;
  getSession(id: string): Promise<Session | undefined>;
  updateSessionChart(id: string, chartData: ChartData): Promise<Session | undefined>;
  
  // Consciousness logging
  createConsciousnessLog(log: InsertConsciousnessLog): Promise<ConsciousnessLog>;
  getConsciousnessLogs(sessionId: string): Promise<ConsciousnessLog[]>;
  getConsciousnessLog(id: string): Promise<ConsciousnessLog | undefined>;
  
  // Analytics
  getRecentLogs(limit?: number): Promise<ConsciousnessLog[]>;
}

export class MemStorage implements IStorage {
  private sessions: Map<string, Session>;
  private consciousnessLogs: Map<string, ConsciousnessLog>;

  constructor() {
    this.sessions = new Map();
    this.consciousnessLogs = new Map();
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const id = randomUUID();
    const session: Session = {
      ...insertSession,
      id,
      created_at: new Date()
    };
    this.sessions.set(id, session);
    return session;
  }

  async getSession(id: string): Promise<Session | undefined> {
    return this.sessions.get(id);
  }

  async updateSessionChart(id: string, chartData: ChartData): Promise<Session | undefined> {
    const session = this.sessions.get(id);
    if (!session) return undefined;
    
    const updated: Session = {
      ...session,
      chart_data: chartData
    };
    this.sessions.set(id, updated);
    return updated;
  }

  async createConsciousnessLog(insertLog: InsertConsciousnessLog): Promise<ConsciousnessLog> {
    const id = randomUUID();
    const log: ConsciousnessLog = {
      ...insertLog,
      id,
      created_at: new Date()
    };
    this.consciousnessLogs.set(id, log);
    return log;
  }

  async getConsciousnessLogs(sessionId: string): Promise<ConsciousnessLog[]> {
    return Array.from(this.consciousnessLogs.values())
      .filter(log => log.session_id === sessionId)
      .sort((a, b) => b.created_at.getTime() - a.created_at.getTime());
  }

  async getConsciousnessLog(id: string): Promise<ConsciousnessLog | undefined> {
    return this.consciousnessLogs.get(id);
  }

  async getRecentLogs(limit: number = 50): Promise<ConsciousnessLog[]> {
    return Array.from(this.consciousnessLogs.values())
      .sort((a, b) => b.created_at.getTime() - a.created_at.getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
