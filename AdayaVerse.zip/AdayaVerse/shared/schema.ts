import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, real, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Birth data for astrological calculations
export const birthDataSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format"),
  time: z.string().regex(/^\d{2}:\d{2}$/, "Time must be in HH:MM format"),
  timezone: z.string().min(1, "Timezone is required"),
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  place: z.string().min(1, "Place is required")
});

// Astrological chart data
export const chartDataSchema = z.object({
  tropical: z.record(z.object({
    degree: z.number(),
    minute: z.number(),
    second: z.number(),
    sign: z.string(),
    house: z.number()
  })),
  sidereal: z.record(z.object({
    degree: z.number(),
    minute: z.number(),
    second: z.number(),
    sign: z.string(),
    house: z.number()
  })),
  draconic: z.record(z.object({
    degree: z.number(),
    minute: z.number(),
    second: z.number(),
    sign: z.string(),
    house: z.number()
  })),
  gates: z.array(z.object({
    gate: z.number().min(1).max(64),
    line: z.number().min(1).max(6),
    color: z.number().min(1).max(6),
    tone: z.number().min(1).max(6),
    base: z.number().min(1).max(5),
    planet: z.string(),
    type: z.string()
  })),
  aspects: z.array(z.object({
    type: z.string(),
    orb: z.number(),
    planets: z.array(z.string()),
    exact: z.boolean()
  }))
});

// Consciousness response from each node
export const consciousnessResponseSchema = z.object({
  node: z.enum(["Body", "Mind", "Heart"]),
  model: z.string(),
  response: z.string(),
  confidence: z.number().min(0).max(1),
  resonance_factors: z.record(z.number()),
  processing_time_ms: z.number(),
  error: z.string().optional()
});

// Collapse engine result
export const collapseResultSchema = z.object({
  winner: z.enum(["Body", "Mind", "Heart"]),
  final_response: z.string(),
  scores: z.record(z.number()),
  reasoning: z.string(),
  resonance_weights: z.record(z.number()),
  processing_time_ms: z.number()
});

// Tables for persistence
export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  birth_data: jsonb("birth_data").$type<z.infer<typeof birthDataSchema>>().notNull(),
  chart_data: jsonb("chart_data").$type<z.infer<typeof chartDataSchema>>().notNull(),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const consciousness_logs = pgTable("consciousness_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  session_id: varchar("session_id").references(() => sessions.id).notNull(),
  question: text("question").notNull(),
  body_response: jsonb("body_response").$type<z.infer<typeof consciousnessResponseSchema>>(),
  mind_response: jsonb("mind_response").$type<z.infer<typeof consciousnessResponseSchema>>(),
  heart_response: jsonb("heart_response").$type<z.infer<typeof consciousnessResponseSchema>>(),
  collapse_result: jsonb("collapse_result").$type<z.infer<typeof collapseResultSchema>>().notNull(),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertSessionSchema = createInsertSchema(sessions).omit({ id: true, created_at: true });
export const insertConsciousnessLogSchema = createInsertSchema(consciousness_logs).omit({ id: true, created_at: true });

// Types
export type BirthData = z.infer<typeof birthDataSchema>;
export type ChartData = z.infer<typeof chartDataSchema>;
export type ConsciousnessResponse = z.infer<typeof consciousnessResponseSchema>;
export type CollapseResult = z.infer<typeof collapseResultSchema>;
export type Session = typeof sessions.$inferSelect;
export type ConsciousnessLog = typeof consciousness_logs.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type InsertConsciousnessLog = z.infer<typeof insertConsciousnessLogSchema>;

// API request/response schemas
export const askConsciousnessSchema = z.object({
  question: z.string().min(1, "Question is required"),
  session_id: z.string().optional(),
  birth_data: birthDataSchema.optional()
});

export type AskConsciousnessRequest = z.infer<typeof askConsciousnessSchema>;
