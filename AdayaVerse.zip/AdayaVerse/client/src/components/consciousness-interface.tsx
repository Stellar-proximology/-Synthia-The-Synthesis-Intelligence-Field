import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { birthDataSchema, type BirthData } from "@shared/schema";
import { Brain, Heart, Zap, MapPin, Clock, Calendar, Loader2, Sparkles } from "lucide-react";
import ChartDisplay from "./chart-display";
import CollapseVisualization from "./collapse-visualization";

interface ChartResponse {
  session_id: string;
  chart_data: any;
  timestamp: string;
}

interface ConsciousnessResponse {
  session_id: string;
  log_id: string;
  question: string;
  winner: "Body" | "Mind" | "Heart";
  final_response: string;
  scores: Record<string, number>;
  reasoning: string;
  all_responses: {
    body?: string;
    mind?: string;
    heart?: string;
  };
  processing_time_ms: number;
  timestamp: string;
}

export default function ConsciousnessInterface() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [chartData, setChartData] = useState<any>(null);
  const [conversationHistory, setConversationHistory] = useState<ConsciousnessResponse[]>([]);
  const { toast } = useToast();

  const birthForm = useForm<BirthData>({
    resolver: zodResolver(birthDataSchema),
    defaultValues: {
      date: "",
      time: "",
      timezone: "America/New_York",
      latitude: 40.7128,
      longitude: -74.0060,
      place: "New York, NY"
    }
  });

  const [question, setQuestion] = useState("");

  // Chart calculation mutation
  const chartMutation = useMutation({
    mutationFn: async (birthData: BirthData) => {
      const response = await apiRequest('POST', '/api/chart', birthData);
      return response.json() as Promise<ChartResponse>;
    },
    onSuccess: (data) => {
      setSessionId(data.session_id);
      setChartData(data.chart_data);
      toast({
        title: "Chart Generated",
        description: "Your astrological charts have been calculated successfully."
      });
    },
    onError: (error) => {
      console.error('Chart calculation failed:', error);
      toast({
        title: "Chart Generation Failed",
        description: error instanceof Error ? error.message : "Failed to generate charts",
        variant: "destructive"
      });
    }
  });

  // Consciousness question mutation
  const consciousnessMutation = useMutation({
    mutationFn: async (questionData: { question: string; session_id?: string }) => {
      const response = await apiRequest('POST', '/api/ask', questionData);
      return response.json() as Promise<ConsciousnessResponse>;
    },
    onSuccess: (data) => {
      setConversationHistory(prev => [...prev, data]);
      setQuestion("");
      toast({
        title: `${data.winner} Node Responded`,
        description: `Processed in ${data.processing_time_ms}ms`
      });
    },
    onError: (error) => {
      console.error('Consciousness query failed:', error);
      toast({
        title: "Consciousness Query Failed",
        description: error instanceof Error ? error.message : "Failed to process question",
        variant: "destructive"
      });
    }
  });

  const onSubmitBirth = (data: BirthData) => {
    chartMutation.mutate(data);
  };

  const onSubmitQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;
    
    if (!sessionId) {
      toast({
        title: "No Session",
        description: "Please generate your charts first",
        variant: "destructive"
      });
      return;
    }

    consciousnessMutation.mutate({
      question: question.trim(),
      session_id: sessionId
    });
  };

  const getNodeIcon = (node: string) => {
    switch (node) {
      case 'Body': return <Zap className="h-4 w-4" />;
      case 'Mind': return <Brain className="h-4 w-4" />;
      case 'Heart': return <Heart className="h-4 w-4" />;
      default: return <Sparkles className="h-4 w-4" />;
    }
  };

  const getNodeColor = (node: string) => {
    switch (node) {
      case 'Body': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      case 'Mind': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'Heart': return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  return (
    <div className="space-y-8">
      {/* Birth Data Input */}
      {!sessionId && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Birth Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...birthForm}>
              <form onSubmit={birthForm.handleSubmit(onSubmitBirth)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={birthForm.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Birth Date</FormLabel>
                        <FormControl>
                          <Input
                            type="date"
                            placeholder="YYYY-MM-DD"
                            data-testid="input-birth-date"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={birthForm.control}
                    name="time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Birth Time</FormLabel>
                        <FormControl>
                          <Input
                            type="time"
                            placeholder="HH:MM"
                            data-testid="input-birth-time"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={birthForm.control}
                    name="timezone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Timezone</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="America/New_York"
                            data-testid="input-timezone"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={birthForm.control}
                    name="latitude"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Latitude</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="any"
                            placeholder="40.7128"
                            data-testid="input-latitude"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={birthForm.control}
                    name="longitude"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Longitude</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="any"
                            placeholder="-74.0060"
                            data-testid="input-longitude"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={birthForm.control}
                    name="place"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Place</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="New York, NY"
                            data-testid="input-place"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button
                  type="submit"
                  disabled={chartMutation.isPending}
                  data-testid="button-generate-chart"
                  className="w-full"
                >
                  {chartMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Generating Charts...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Generate Consciousness Charts
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}

      {/* Chart Display */}
      {chartData && <ChartDisplay chartData={chartData} />}

      {/* Question Interface */}
      {sessionId && (
        <Card>
          <CardHeader>
            <CardTitle>Ask the Consciousness Nodes</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmitQuestion} className="space-y-4">
              <div>
                <Label htmlFor="question">Your Question</Label>
                <Textarea
                  id="question"
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  placeholder="What should I focus on this week? How can I better understand my purpose? What does my chart say about relationships?"
                  className="min-h-[100px]"
                  data-testid="textarea-question"
                />
              </div>
              <Button
                type="submit"
                disabled={!question.trim() || consciousnessMutation.isPending}
                data-testid="button-ask-consciousness"
                className="w-full"
              >
                {consciousnessMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing Across All Nodes...
                  </>
                ) : (
                  "Ask the Consciousness Network"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Conversation History */}
      {conversationHistory.length > 0 && (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold">Consciousness Dialogue</h2>
          {conversationHistory.map((response, index) => (
            <Card key={response.log_id} className="overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold text-lg mb-1">{response.question}</h3>
                    <div className="flex items-center gap-2">
                      <Badge className={getNodeColor(response.winner)}>
                        <span className="flex items-center gap-1">
                          {getNodeIcon(response.winner)}
                          {response.winner} Node
                        </span>
                      </Badge>
                      <span className="text-sm text-gray-500">
                        {response.processing_time_ms}ms
                      </span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Final Response */}
                <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Final Response</h4>
                  <p className="text-sm leading-relaxed">{response.final_response}</p>
                </div>

                {/* Collapse Visualization */}
                <CollapseVisualization
                  scores={response.scores}
                  winner={response.winner}
                  reasoning={response.reasoning}
                  allResponses={response.all_responses}
                />

                <Separator />

                {/* Collapse Reasoning */}
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  <strong>Collapse Reasoning:</strong> {response.reasoning}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
