import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, Heart, Zap, Target, Info } from "lucide-react";

interface CollapseVisualizationProps {
  scores: Record<string, number>;
  winner: "Body" | "Mind" | "Heart";
  reasoning: string;
  allResponses: {
    body?: string;
    mind?: string;
    heart?: string;
  };
}

export default function CollapseVisualization({ 
  scores, 
  winner, 
  reasoning, 
  allResponses 
}: CollapseVisualizationProps) {
  const getNodeIcon = (node: string) => {
    switch (node) {
      case 'Body': return <Zap className="h-4 w-4" />;
      case 'Mind': return <Brain className="h-4 w-4" />;
      case 'Heart': return <Heart className="h-4 w-4" />;
      default: return <Target className="h-4 w-4" />;
    }
  };

  const getNodeColor = (node: string, isWinner: boolean = false) => {
    const base = {
      'Body': isWinner ? 'bg-orange-500' : 'bg-orange-200 dark:bg-orange-700',
      'Mind': isWinner ? 'bg-blue-500' : 'bg-blue-200 dark:bg-blue-700',
      'Heart': isWinner ? 'bg-pink-500' : 'bg-pink-200 dark:bg-pink-700'
    };
    return base[node as keyof typeof base] || 'bg-gray-200 dark:bg-gray-700';
  };

  const getBadgeColor = (node: string) => {
    switch (node) {
      case 'Body': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      case 'Mind': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'Heart': return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  return (
    <div className="space-y-4">
      {/* Collapse Scores */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Target className="h-4 w-4" />
            Consciousness Node Scores
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Object.entries(scores).map(([node, score]) => (
              <div key={node} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge className={getBadgeColor(node)}>
                      <span className="flex items-center gap-1">
                        {getNodeIcon(node)}
                        {node}
                      </span>
                    </Badge>
                    {node === winner && (
                      <Badge variant="default" className="text-xs">
                        Winner
                      </Badge>
                    )}
                  </div>
                  <span className="text-sm font-mono">
                    {(score * 100).toFixed(1)}%
                  </span>
                </div>
                <Progress 
                  value={score * 100} 
                  className={`h-2 ${getNodeColor(node, node === winner)}`}
                />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* All Node Responses */}
      {Object.keys(allResponses).some(key => allResponses[key as keyof typeof allResponses]) && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Info className="h-4 w-4" />
              All Node Responses
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue={winner.toLowerCase()} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                {Object.entries(allResponses).map(([node, response]) => (
                  response && (
                    <TabsTrigger 
                      key={node} 
                      value={node} 
                      className="flex items-center gap-2"
                      disabled={!response}
                    >
                      {getNodeIcon(node.charAt(0).toUpperCase() + node.slice(1))}
                      {node.charAt(0).toUpperCase() + node.slice(1)}
                      {node.charAt(0).toUpperCase() + node.slice(1) === winner && (
                        <Badge variant="secondary" className="text-xs ml-1">
                          Winner
                        </Badge>
                      )}
                    </TabsTrigger>
                  )
                ))}
              </TabsList>

              {Object.entries(allResponses).map(([node, response]) => (
                response && (
                  <TabsContent key={node} value={node} className="mt-4">
                    <div className={`p-4 rounded-lg border-2 ${
                      node.charAt(0).toUpperCase() + node.slice(1) === winner 
                        ? 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950' 
                        : 'border-gray-200 bg-gray-50 dark:border-gray-700 dark:bg-gray-800'
                    }`}>
                      <div className="flex items-center gap-2 mb-3">
                        <Badge className={getBadgeColor(node.charAt(0).toUpperCase() + node.slice(1))}>
                          <span className="flex items-center gap-1">
                            {getNodeIcon(node.charAt(0).toUpperCase() + node.slice(1))}
                            {node.charAt(0).toUpperCase() + node.slice(1)} Node
                          </span>
                        </Badge>
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          Score: {((scores[node.charAt(0).toUpperCase() + node.slice(1)] || 0) * 100).toFixed(1)}%
                        </span>
                      </div>
                      <p className="text-sm leading-relaxed">{response}</p>
                    </div>
                  </TabsContent>
                )
              ))}
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
