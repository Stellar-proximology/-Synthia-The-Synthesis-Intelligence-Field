import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sun, Moon, Star, Zap, Brain, Heart } from "lucide-react";

interface ChartDisplayProps {
  chartData: {
    tropical: Record<string, any>;
    sidereal: Record<string, any>;
    draconic: Record<string, any>;
    gates: Array<{
      gate: number;
      line: number;
      color: number;
      tone: number;
      base: number;
      planet: string;
      type: string;
    }>;
    aspects: Array<{
      type: string;
      orb: number;
      planets: string[];
      exact: boolean;
    }>;
  };
}

export default function ChartDisplay({ chartData }: ChartDisplayProps) {
  const getPlanetIcon = (planet: string) => {
    switch (planet.toLowerCase()) {
      case 'sun': return <Sun className="h-4 w-4" />;
      case 'moon': return <Moon className="h-4 w-4" />;
      default: return <Star className="h-4 w-4" />;
    }
  };

  const getSystemIcon = (type: string) => {
    switch (type) {
      case 'tropical': return <Zap className="h-4 w-4 text-orange-600" />;
      case 'sidereal': return <Brain className="h-4 w-4 text-blue-600" />;
      case 'draconic': return <Heart className="h-4 w-4 text-pink-600" />;
      default: return <Star className="h-4 w-4" />;
    }
  };

  const getSystemColor = (type: string) => {
    switch (type) {
      case 'tropical': return 'border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950';
      case 'sidereal': return 'border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950';
      case 'draconic': return 'border-pink-200 bg-pink-50 dark:border-pink-800 dark:bg-pink-950';
      default: return 'border-gray-200 bg-gray-50 dark:border-gray-800 dark:bg-gray-950';
    }
  };

  const formatPosition = (position: any) => {
    return `${position.degree}°${position.minute}'${position.second}" ${position.sign} (House ${position.house})`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Star className="h-5 w-5" />
          Astrological Charts
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="tropical" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="tropical" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Tropical (Body)
            </TabsTrigger>
            <TabsTrigger value="sidereal" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              Sidereal (Mind)
            </TabsTrigger>
            <TabsTrigger value="draconic" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              Draconic (Heart)
            </TabsTrigger>
          </TabsList>

          <TabsContent value="tropical" className="mt-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-orange-700 dark:text-orange-300">
                Tropical Positions (Body Consciousness)
              </h3>
              <div className="grid gap-3">
                {Object.entries(chartData.tropical).map(([planet, position]) => (
                  <div key={planet} className="flex items-center justify-between p-3 bg-orange-50 dark:bg-orange-950 rounded-lg border border-orange-200 dark:border-orange-800">
                    <div className="flex items-center gap-2">
                      {getPlanetIcon(planet)}
                      <span className="font-medium capitalize">{planet}</span>
                    </div>
                    <span className="text-sm font-mono">{formatPosition(position)}</span>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="sidereal" className="mt-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-blue-700 dark:text-blue-300">
                Sidereal Positions (Mind Consciousness)
              </h3>
              <div className="grid gap-3">
                {Object.entries(chartData.sidereal).map(([planet, position]) => (
                  <div key={planet} className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                    <div className="flex items-center gap-2">
                      {getPlanetIcon(planet)}
                      <span className="font-medium capitalize">{planet}</span>
                    </div>
                    <span className="text-sm font-mono">{formatPosition(position)}</span>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="draconic" className="mt-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-pink-700 dark:text-pink-300">
                Draconic Positions (Heart Consciousness)
              </h3>
              <div className="grid gap-3">
                {Object.entries(chartData.draconic).map(([planet, position]) => (
                  <div key={planet} className="flex items-center justify-between p-3 bg-pink-50 dark:bg-pink-950 rounded-lg border border-pink-200 dark:border-pink-800">
                    <div className="flex items-center gap-2">
                      {getPlanetIcon(planet)}
                      <span className="font-medium capitalize">{planet}</span>
                    </div>
                    <span className="text-sm font-mono">{formatPosition(position)}</span>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Human Design Gates */}
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-4">Human Design Gates</h3>
          <div className="grid gap-2">
            {chartData.gates.map((gate, index) => (
              <div key={index} className={`p-3 rounded-lg border ${getSystemColor(gate.type)}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {getSystemIcon(gate.type)}
                    <span className="font-medium">Gate {gate.gate}.{gate.line}</span>
                    <Badge variant="outline" className="text-xs">
                      {gate.planet}
                    </Badge>
                  </div>
                  <div className="text-sm font-mono">
                    C{gate.color}•T{gate.tone}•B{gate.base}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Aspects */}
        {chartData.aspects.length > 0 && (
          <div className="mt-8">
            <h3 className="text-lg font-semibold mb-4">Planetary Aspects</h3>
            <div className="grid gap-2">
              {chartData.aspects.map((aspect, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Badge variant={aspect.exact ? "default" : "secondary"}>
                      {aspect.type}
                    </Badge>
                    <span className="text-sm">
                      {aspect.planets.join(' - ')}
                    </span>
                  </div>
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    {aspect.orb.toFixed(1)}° orb
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
