import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import ConsciousnessInterface from "@/components/consciousness-interface";

export default function Consciousness() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-pink-50 dark:from-violet-950 dark:via-gray-900 dark:to-pink-950">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm" data-testid="button-back-home">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-violet-600 to-pink-600 bg-clip-text text-transparent">
              Consciousness Interface
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Engage with Body, Mind, and Heart consciousness nodes
            </p>
          </div>
        </div>

        {/* Main Interface */}
        <ConsciousnessInterface />
      </div>
    </div>
  );
}
