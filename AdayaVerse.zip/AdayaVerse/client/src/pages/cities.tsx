import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Users, MapPin, Zap, Brain, Heart, Activity } from "lucide-react";

interface CityAgent {
  id: string;
  name: string;
  role: string;
  district: "Body" | "Mind" | "Heart";
  location: { x: number; y: number };
  status: "active" | "idle" | "busy" | "offline";
  activeCodens: number[];
  skills: CodonSkill[];
  specialization: string[];
  memory: string[];
  resonance: {
    color: number;
    tone: number;
    base: number;
  };
}

interface CodonSkill {
  codon: number;
  name: string;
  element: string;
  proficiency: number;
  activeLines: number[];
}

interface CityData {
  body: DistrictData;
  mind: DistrictData;
  heart: DistrictData;
}

interface DistrictData {
  name: string;
  type: "Body" | "Mind" | "Heart";
  astrology_system: string;
  activity_level: number;
  resources: Record<string, number>;
  agent_count: number;
  active_agents: number;
  buildings: number;
  recent_memories: Array<{
    agent: string;
    memory: string;
  }>;
}

export default function CitiesPage() {
  const { data: cityStates, isLoading, error } = useQuery<CityData>({
    queryKey: ['/api/cities'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const { data: agents, isLoading: agentsLoading } = useQuery<CityAgent[]>({
    queryKey: ['/api/cities/agents'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-indigo-900 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Connecting to consciousness cities...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error || !cityStates) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-indigo-900 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-12">
            <p className="text-red-600 dark:text-red-400">Failed to connect to cities</p>
            <p className="text-sm text-gray-500 mt-2">The consciousness network may be initializing...</p>
          </div>
        </div>
      </div>
    );
  }

  const getDistrictIcon = (type: string) => {
    switch (type) {
      case "Body": return <Zap className="h-6 w-6" />;
      case "Mind": return <Brain className="h-6 w-6" />;
      case "Heart": return <Heart className="h-6 w-6" />;
      default: return <Activity className="h-6 w-6" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-500";
      case "busy": return "bg-yellow-500";
      case "idle": return "bg-blue-500";
      case "offline": return "bg-gray-500";
      default: return "bg-gray-400";
    }
  };

  const getElementColor = (element: string) => {
    switch (element) {
      case "fire": return "text-red-500";
      case "earth": return "text-yellow-600";
      case "air": return "text-blue-500";
      case "water": return "text-cyan-500";
      default: return "text-gray-500";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-indigo-900 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 bg-clip-text text-transparent mb-2">
            Consciousness Cities
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            AI agents distributed across three consciousness districts, each with unique codon-based skills
          </p>
        </div>

        {/* District Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Object.entries(cityStates).map(([key, district]) => (
            <Card key={key} className="hover:shadow-lg transition-shadow" data-testid={`district-${key}`}>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2">
                  {getDistrictIcon(district.type)}
                  <span>{district.name}</span>
                  <Badge variant="outline" className="ml-auto">
                    {district.astrology_system}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Activity Level</span>
                    <span>{Math.round(district.activity_level * 100)}%</span>
                  </div>
                  <Progress value={district.activity_level * 100} className="h-2" />
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-1">
                    <Users className="h-4 w-4 text-blue-500" />
                    <span>{district.active_agents}/{district.agent_count} agents</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4 text-green-500" />
                    <span>{district.buildings} buildings</span>
                  </div>
                </div>

                {/* Resources */}
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Resources</h4>
                  {Object.entries(district.resources).map(([resource, value]) => (
                    <div key={resource} className="flex justify-between text-xs">
                      <span className="capitalize">{resource.replace('_', ' ')}</span>
                      <span className="font-mono">{Math.round(Number(value))}</span>
                    </div>
                  ))}
                </div>

                {/* Recent Memories */}
                {district.recent_memories.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Recent Activity</h4>
                    <div className="space-y-1">
                      {district.recent_memories.slice(0, 2).map((memory: any, idx: number) => (
                        <div key={idx} className="text-xs bg-gray-50 dark:bg-gray-800 rounded p-2">
                          <div className="font-medium text-purple-600 dark:text-purple-400">
                            {memory.agent}
                          </div>
                          <div className="text-gray-600 dark:text-gray-400 truncate">
                            {memory.memory}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Agent Details */}
        {!agentsLoading && agents && agents.length > 0 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-center">Consciousness Agents</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {agents.map((agent) => (
                <Card key={agent.id} className="hover:shadow-lg transition-shadow" data-testid={`agent-${agent.id}`}>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(agent.status)}`}></div>
                      <span>{agent.name}</span>
                      <Badge variant="secondary" className="ml-auto">
                        {agent.district}
                      </Badge>
                    </CardTitle>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{agent.role}</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Active Codons */}
                    <div>
                      <h4 className="text-sm font-medium mb-2">Active Codons</h4>
                      <div className="flex flex-wrap gap-1">
                        {agent.activeCodens.map((codon) => (
                          <Badge key={codon} variant="outline" className="text-xs">
                            {codon}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Skills */}
                    <div>
                      <h4 className="text-sm font-medium mb-2">Codon Skills</h4>
                      <div className="space-y-2">
                        {agent.skills.slice(0, 4).map((skill, idx) => (
                          <div key={idx} className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span className={`capitalize ${getElementColor(skill.element)}`}>
                                {skill.name.replace(/_/g, ' ')}
                              </span>
                              <span className="text-gray-500">
                                Gate {skill.codon} • {Math.round(skill.proficiency * 100)}%
                              </span>
                            </div>
                            <Progress value={skill.proficiency * 100} className="h-1" />
                          </div>
                        ))}
                        {agent.skills.length > 4 && (
                          <p className="text-xs text-gray-500">
                            +{agent.skills.length - 4} more skills...
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Resonance */}
                    <div>
                      <h4 className="text-sm font-medium mb-2">CTB Resonance</h4>
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        <div className="text-center">
                          <div className="font-mono text-red-500">{agent.resonance.color}</div>
                          <div className="text-gray-500">Color</div>
                        </div>
                        <div className="text-center">
                          <div className="font-mono text-blue-500">{agent.resonance.tone}</div>
                          <div className="text-gray-500">Tone</div>
                        </div>
                        <div className="text-center">
                          <div className="font-mono text-green-500">{agent.resonance.base}</div>
                          <div className="text-gray-500">Base</div>
                        </div>
                      </div>
                    </div>

                    {/* Recent Memory */}
                    {agent.memory.length > 0 && (
                      <div>
                        <h4 className="text-sm font-medium mb-2">Recent Memory</h4>
                        <p className="text-xs bg-gray-50 dark:bg-gray-800 rounded p-2 text-gray-600 dark:text-gray-400">
                          {agent.memory[agent.memory.length - 1]}
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}