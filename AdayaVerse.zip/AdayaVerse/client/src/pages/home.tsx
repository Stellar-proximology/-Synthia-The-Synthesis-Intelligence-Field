import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Brain, Sparkles, Heart, Zap, ChevronRight, Activity } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface HealthStatus {
  status: string;
  services: {
    ollama: boolean;
    astrology: boolean;
    collapse: boolean;
  };
  timestamp: string;
}

interface RecentActivity {
  logs: Array<{
    id: string;
    question: string;
    winner: "Body" | "Mind" | "Heart";
    final_response: string;
    scores: Record<string, number>;
    created_at: string;
  }>;
  total: number;
}

export default function Home() {
  const { data: health } = useQuery<HealthStatus>({
    queryKey: ['/api/health'],
    refetchInterval: 10000, // Check health every 10 seconds
  });

  const { data: recent } = useQuery<RecentActivity>({
    queryKey: ['/api/recent'],
    refetchInterval: 30000, // Refresh recent activity every 30 seconds
  });

  const getNodeIcon = (node: string) => {
    switch (node) {
      case 'Body': return <Zap className="h-4 w-4" />;
      case 'Mind': return <Brain className="h-4 w-4" />;
      case 'Heart': return <Heart className="h-4 w-4" />;
      default: return <Sparkles className="h-4 w-4" />;
    }
  };

  const getNodeColor = (node: string) => {
    switch (node) {
      case 'Body': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      case 'Mind': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'Heart': return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-pink-50 dark:from-violet-950 dark:via-gray-900 dark:to-pink-950">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="relative">
              <Sparkles className="h-8 w-8 text-violet-600 dark:text-violet-400" />
              <div className="absolute -top-1 -right-1 h-3 w-3 bg-pink-500 rounded-full animate-pulse" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-violet-600 to-pink-600 bg-clip-text text-transparent">
              Cynthia
            </h1>
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-2">
            Three-Brain Consciousness Simulation
          </p>
          <p className="text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">
            Experience the convergence of Body (Tropical), Mind (Sidereal), and Heart (Draconic) consciousness 
            through advanced astrological chart mathematics and intelligent collapse algorithms.
          </p>
        </div>

        {/* System Status */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              System Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            {health ? (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <Badge variant={health.status === 'healthy' ? 'default' : 'destructive'} className="mb-2">
                    {health.status}
                  </Badge>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Overall</p>
                </div>
                <div className="text-center">
                  <Badge variant={health.services.ollama ? 'default' : 'destructive'} className="mb-2">
                    {health.services.ollama ? 'Online' : 'Offline'}
                  </Badge>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Ollama LLMs</p>
                </div>
                <div className="text-center">
                  <Badge variant={health.services.astrology ? 'default' : 'destructive'} className="mb-2">
                    {health.services.astrology ? 'Ready' : 'Error'}
                  </Badge>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Astrology Engine</p>
                </div>
                <div className="text-center">
                  <Badge variant={health.services.collapse ? 'default' : 'destructive'} className="mb-2">
                    {health.services.collapse ? 'Active' : 'Inactive'}
                  </Badge>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Collapse Engine</p>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-500 dark:text-gray-400">
                Checking system status...
              </div>
            )}
          </CardContent>
        </Card>

        {/* Consciousness Nodes */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="relative overflow-hidden">
            <div className="absolute top-0 right-0 w-20 h-20 bg-orange-100 dark:bg-orange-900 rounded-full -mr-10 -mt-10" />
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-700 dark:text-orange-300">
                <Zap className="h-5 w-5" />
                Body Node
              </CardTitle>
              <CardDescription>Tropical Astrology • TinyLlama</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Processes through embodied wisdom and physical manifestation. 
                Uses Tropical astrological calculations for action-oriented guidance.
              </p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <div className="absolute top-0 right-0 w-20 h-20 bg-blue-100 dark:bg-blue-900 rounded-full -mr-10 -mt-10" />
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-300">
                <Brain className="h-5 w-5" />
                Mind Node
              </CardTitle>
              <CardDescription>Sidereal Astrology • Mistral</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Analyzes through strategic thinking and mental clarity. 
                Uses Sidereal astrological calculations for analytical frameworks.
              </p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <div className="absolute top-0 right-0 w-20 h-20 bg-pink-100 dark:bg-pink-900 rounded-full -mr-10 -mt-10" />
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-pink-700 dark:text-pink-300">
                <Heart className="h-5 w-5" />
                Heart Node
              </CardTitle>
              <CardDescription>Draconic Astrology • Phi</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Responds through emotional intelligence and soul wisdom. 
                Uses Draconic astrological calculations for value-based guidance.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        {recent && recent.logs.length > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Recent Consciousness Sessions</CardTitle>
              <CardDescription>Latest interactions across all nodes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recent.logs.slice(0, 5).map((log) => (
                  <div key={log.id} className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex-shrink-0 mt-1">
                      <Badge className={getNodeColor(log.winner)}>
                        <span className="flex items-center gap-1">
                          {getNodeIcon(log.winner)}
                          {log.winner}
                        </span>
                      </Badge>
                    </div>
                    <div className="flex-grow min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-1">
                        {log.question}
                      </p>
                      <p className="text-xs text-gray-600 dark:text-gray-400 mb-2">
                        {log.final_response}
                      </p>
                      <div className="flex gap-2 text-xs">
                        {Object.entries(log.scores).map(([node, score]) => (
                          <span key={node} className="text-gray-500 dark:text-gray-400">
                            {node}: {(score * 100).toFixed(0)}%
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="text-xs text-gray-400 dark:text-gray-500 flex-shrink-0">
                      {new Date(log.created_at).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Get Started */}
        <Card className="text-center">
          <CardContent className="pt-6">
            <h3 className="text-2xl font-bold mb-4">Ready to Explore Consciousness?</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-md mx-auto">
              Enter your birth information to generate your astrological charts and begin 
              your conversation with the three nodes of consciousness.
            </p>
            <Link href="/consciousness">
              <Button size="lg" className="bg-gradient-to-r from-violet-600 to-pink-600 hover:from-violet-700 hover:to-pink-700" data-testid="button-start-consciousness">
                Begin Consciousness Session
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
