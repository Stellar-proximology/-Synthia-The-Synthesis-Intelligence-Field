# Overview

This is Cynthia, a sophisticated consciousness interface that combines astrological chart calculation with a three-brain AI system (Body/Mind/Heart). The application calculates precise astrological charts using multiple coordinate systems (tropical, sidereal, draconic) and Human Design gates, then feeds this cosmic data to three specialized AI nodes that compete and collaborate to provide personalized guidance. A "collapse engine" evaluates and synthesizes their responses based on relevance, coherence, chart resonance, and safety metrics.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React with TypeScript**: Modern SPA built with Vite for fast development and building
- **UI Framework**: Comprehensive shadcn/ui component library with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with custom design tokens and dark mode support
- **State Management**: TanStack Query for server state, React hooks for local state
- **Routing**: Wouter for lightweight client-side routing with /cities and /consciousness pages
- **Form Handling**: React Hook Form with Zod validation for type-safe forms

## Backend Architecture
- **Express.js API**: RESTful server with TypeScript for type safety
- **City-Distributed Consciousness**: Three districts (Soma Plaza, Cerebral Commons, Empathy Enclave) each with specialized AI agents
- **Electron Collapse Engine**: Advanced MBH (Mind/Body/Heart) candidate evaluation system integrated into each city district
- **64 Codon System**: I Ching gate-based skill mapping system determining agent specializations and capabilities
- **Three-Brain AI System**: 
  - Body Node: Tropical astrology + TinyLlama + kinetic/action wisdom  
  - Mind Node: Sidereal astrology + Mistral + analytical/logical processing
  - Heart Node: Draconic astrology + Phi + emotional/values-driven guidance
- **Astrological Calculator**: Multi-system planetary calculations across tropical, sidereal, and draconic coordinates
- **Human Design Integration**: CTB (Color/Tone/Base) resonance weights with gate/line/codon mapping

## Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Session Management**: In-memory storage with interface for future database persistence
- **Schema Validation**: Zod schemas shared between frontend and backend for consistent data validation

## Authentication and Authorization
- Currently using session-based storage without authentication
- Built with extensible session management interface for future auth integration

## Core Data Models
- **Sessions**: User interaction sessions with optional chart data
- **Consciousness Logs**: Complete records of AI interactions including all three responses, scores, and final collapsed output
- **Birth Data**: Structured astrological input (date, time, location)
- **Chart Data**: Multi-system planetary positions, Human Design gates, and astrological aspects

# External Dependencies

## AI Services
- **Ollama**: Local LLM inference server powering the three consciousness nodes
- **Configurable Models**: Separate model assignments for Body/Mind/Heart personalities
- **Timeout Management**: Graceful handling of model response delays

## Astrological Services
- **Swiss Ephemeris**: Planned integration for precise planetary position calculations
- **Neon Database**: Serverless PostgreSQL for production data persistence
- **Human Design System**: Custom gate/codon/element mapping tables for consciousness resonance

## Development Tools
- **Vite**: Fast build tool with HMR and TypeScript support
- **ESBuild**: Production bundling for server code
- **Drizzle Kit**: Database migration management
- **PostCSS**: CSS processing with Tailwind integration

## UI Libraries
- **Radix UI**: Comprehensive headless component primitives
- **Lucide React**: Modern icon library
- **Class Variance Authority**: Type-safe component variant management
- **Embla Carousel**: Touch-friendly carousel components