# Parses convos to extract intent/specification
