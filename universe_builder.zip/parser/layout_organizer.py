# Extracts layout and directory structure from input files
