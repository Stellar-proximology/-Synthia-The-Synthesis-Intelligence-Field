# Classifies uploaded files by type and purpose
