# Logic to combine parser and scaffolder
