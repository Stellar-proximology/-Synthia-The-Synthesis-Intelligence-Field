# Entry point for Flask app
