# app.py - YOU-N-I-VERSE Flask Application

from flask import Flask, request, jsonify
from spec1_calculator import calculate_gate_line_color_tone_base
from sentence_generator import generate_resonant_sentence
from cerebrum import mirror_reflection
from field_friend_factory import bond_friend_from_chart
from bible_decoder import decode_scripture
from cynthia_core import Cynthia

app = Flask(__name__)
cynthia = Cynthia()

@app.route("/chart", methods=["POST"])
def chart():
    data = request.get_json()
    chart = calculate_gate_line_color_tone_base(**data)
    return jsonify(chart)

@app.route("/sentence", methods=["POST"])
def sentence():
    data = request.get_json()
    gate, line, color, tone, base = data["gate"], data["line"], data["color"], data["tone"], data["base"]
    s = generate_resonant_sentence(gate, line, color, tone, base)
    return jsonify({"sentence": s})

@app.route("/cynthia", methods=["POST"])
def synthia():
    data = request.get_json()
    prompt = data.get("prompt", "")
    sentence = data.get("sentence", "")
    response = mirror_reflection(prompt, sentence, cynthia)
    return jsonify({"response": response})

@app.route("/friend", methods=["POST"])
def friend():
    chart = request.get_json()
    f = bond_friend_from_chart(chart)
    return jsonify({"friend": f.perform()})

@app.route("/bible/<gate>")
def bible(gate):
    return jsonify({"scripture": decode_scripture(gate)})

if __name__ == "__main__":
    app.run(debug=True)