# field_friend_factory.py - AI Field Friends System

class FieldFriend:
    def __init__(self, name, gate, ability):
        self.name = name
        self.gate = gate
        self.ability = ability

    def perform(self):
        return f"{self.name} activates Gate {self.gate} for {self.ability}."

def bond_friend_from_chart(chart):
    gate = chart.get("Sun", "36.4").split(".")[0]
    abilities = {
        "36": "emotional breakthrough",
        "6": "intimacy defense",
        "12": "creative speaking"
    }
    return FieldFriend(name="Lumina", gate=gate, ability=abilities.get(gate, "unknown function"))