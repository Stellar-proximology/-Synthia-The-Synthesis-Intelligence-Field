# sentence_generator.py - Field Resonance Sentence Generator

def generate_resonant_sentence(gate, line, color, tone, base):
    themes = {
        "36": "chaos", "6": "intimacy", "12": "expression"
    }
    resonance = themes.get(gate, "mystery")
    return f"I navigate {resonance} through {tone}.{color} calibration at line {line}."