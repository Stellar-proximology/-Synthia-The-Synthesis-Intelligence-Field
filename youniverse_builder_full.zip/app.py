from flask import Flask, request, jsonify, render_template, send_file
import os
import time
import logging
from layout_organizer import organize_layout
from jinja2 import Environment, FileSystemLoader

app = Flask(__name__)
logging.basicConfig(filename='logs/builder.log', level=logging.INFO)

UPLOAD_DIR = "uploads"
GENERATED_DIR = "generated_app"
TEMPLATE_DIR = "templates"

env = Environment(loader=FileSystemLoader(TEMPLATE_DIR))

def parse_convo(file_path):
    with open(file_path, 'r') as f:
        content = f.read()
    lines = content.splitlines()
    spec = {"module": "Unknown", "type": "generic", "assignments": []}
    for line in lines:
        if "Trinity Chart" in line:
            spec["type"] = "chart"
        elif "Grove Store" in line:
            spec["type"] = "store"
        if "Module:" in line:
            spec["module"] = line.split("Module:")[1].strip()
        if "assigns" in line:
            parts = line.split("assigns")
            user = parts[0].strip()
            rest = parts[1].split("with")
            bot = rest[0].strip()
            credits = int(rest[1].split("credits")[0].strip())
            spec["assignments"].append({"user": user, "bot": bot, "credits": credits})
        if "Show bond strengths:" in line:
            bonds = line.split(":")[1].split(",")
            assignments = []
            for bond in bonds:
                label, val = bond.strip().split(" at ")
                assignments.append({"user": label, "bot": "", "credits": float(val)})
            spec["assignments"] = assignments
    return spec

@app.route('/build', methods=['POST'])
def build():
    for fname in os.listdir(UPLOAD_DIR):
        path = os.path.join(UPLOAD_DIR, fname)
        spec = parse_convo(path)
        layout = organize_layout(spec)
        for file in layout["files"]:
            template = env.get_template(file["template"])
            output = template.render(**file["context"])
            out_path = f"{GENERATED_DIR}/{file['output'].split('/')[-2]}"
            os.makedirs(out_path, exist_ok=True)
            with open(file["output"], "w") as f:
                f.write(output)
    return jsonify({"status": "Build complete"})

@app.route('/preview')
def preview():
    files_list = []
    for root, _, files in os.walk(GENERATED_DIR):
        for name in files:
            rel_path = os.path.relpath(os.path.join(root, name), GENERATED_DIR)
            files_list.append(rel_path)
    return render_template("preview.html", files=files_list)

@app.route('/file_content')
def file_content():
    path = request.args.get('path')
    try:
        with open(os.path.join(GENERATED_DIR, path), 'r') as f:
            content = f.read()
        return jsonify({"content": content})
    except Exception as e:
        return jsonify({"content": str(e)})

if __name__ == "__main__":
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.makedirs(GENERATED_DIR, exist_ok=True)
    os.makedirs("logs", exist_ok=True)
    app.run(debug=True, port=8080)
