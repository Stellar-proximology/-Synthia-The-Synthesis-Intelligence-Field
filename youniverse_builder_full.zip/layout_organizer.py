import os
import json

def organize_layout(spec_data):
    """Create folder layout and file specs based on parsed intent."""
    module_name = spec_data.get("module", "GenericModule")
    layout = {
        "module_folder": f"/generated_app/{module_name.lower()}",
        "files": []
    }

    if spec_data.get("type") == "chart":
        layout["files"].append({
            "template": "chart.html.j2",
            "output": f"{layout['module_folder']}/{module_name}_chart.html",
            "context": spec_data
        })
    elif spec_data.get("type") == "store":
        layout["files"].append({
            "template": "store.html.j2",
            "output": f"{layout['module_folder']}/{module_name}_store.html",
            "context": spec_data
        })
        layout["files"].append({
            "template": "store_logic.py.j2",
            "output": f"{layout['module_folder']}/{module_name}_logic.py",
            "context": spec_data
        })
    return layout
