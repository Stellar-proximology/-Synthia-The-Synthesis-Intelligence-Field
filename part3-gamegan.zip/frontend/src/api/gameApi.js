// frontend/src/api/gameApi.js
import axios from 'axios';
const API = '/api';

export const getProgress = (user='anon') => axios.get(`${API}/game/progress`, { params:{ user } });
export const seedQuests = (user='anon') => axios.post(`${API}/game/seed`, { user });
export const trackEvent = (payload) => axios.post(`${API}/game/event`, payload);
export const claimQuest = (user='anon', questId) => axios.post(`${API}/game/claim`, { user, questId });