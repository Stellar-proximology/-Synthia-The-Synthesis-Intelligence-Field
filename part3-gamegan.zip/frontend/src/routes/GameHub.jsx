// frontend/src/routes/GameHub.jsx
import { useEffect, useState } from 'react';
import { getProgress, seedQuests, trackEvent, claimQuest } from '../api/gameApi';
import { markComplete } from '../api/swarmApi';

export default function GameHub(){
  const [p, setP] = useState(null);
  const [busy, setBusy] = useState(false);
  const user = 'anon';

  const load = async () => {
    const { data } = await getProgress(user);
    setP(data);
  };

  useEffect(()=>{ load(); }, []);

  const doSeed = async ()=>{
    setBusy(true);
    await seedQuests(user);
    await load();
    setBusy(false);
  };

  const simulate = async (kind) => {
    setBusy(true);
    if(kind==='impulse') await trackEvent({ user, type:'thought', channel:'impulse', field:'Heart' });
    if(kind==='thought')  await trackEvent({ user, type:'thought', channel:'thought', field:'Mind' });
    if(kind==='action')  await trackEvent({ user, type:'thought', channel:'action', field:'Body' });
    await load();
    setBusy(false);
  };

  const claim = async (q) => {
    setBusy(true);
    await claimQuest(user, q.id);
    await load();
    setBusy(false);
  };

  const completeGateAndTrack = async (field='Mind', gate=16) => {
    setBusy(true);
    try{
      await markComplete(field, gate);
      await trackEvent({ user, type:'gateComplete', field, gate });
    }finally{
      await load();
      setBusy(false);
    }
  };

  if(!p) return <div className="p-4 text-white">Loading GameGAN…</div>;

  const pct = Math.min(100, Math.round((p.xp % 100)));
  return (
    <div className="p-4 max-w-3xl mx-auto text-white">
      <h1 className="text-2xl font-bold mb-2">🎮 GameGAN — Life Progression</h1>
      <div className="bg-slate-800 rounded-xl p-3 mb-3">
        <div className="flex items-center justify-between">
          <div>Level <span className="font-bold">{p.level}</span></div>
          <div>{p.xp} XP</div>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-2 mt-2">
          <div className="bg-violet-500 h-2 rounded-full" style={{ width: `${pct}%`}}></div>
        </div>
        {p.badges?.length ? <div className="mt-2 text-sm opacity-90">Badges: {p.badges.join(' • ')}</div> : null}
      </div>

      <div className="flex gap-2 mb-4">
        <button onClick={doSeed} disabled={busy} className="bg-emerald-600 hover:bg-emerald-500 px-3 py-2 rounded">Seed Quests</button>
        <button onClick={()=>simulate('impulse')} disabled={busy} className="bg-pink-600 hover:bg-pink-500 px-3 py-2 rounded">+ Heart Impulse</button>
        <button onClick={()=>simulate('thought')} disabled={busy} className="bg-sky-600 hover:bg-sky-500 px-3 py-2 rounded">+ Mind Thought</button>
        <button onClick={()=>simulate('action')} disabled={busy} className="bg-amber-600 hover:bg-amber-500 px-3 py-2 rounded">+ Body Action</button>
        <button onClick={()=>completeGateAndTrack('Mind',16)} disabled={busy} className="bg-indigo-600 hover:bg-indigo-500 px-3 py-2 rounded">Complete Gate 16</button>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {(p.quests||[]).map(q=>(
          <div key={q.id} className="bg-slate-800 rounded-xl p-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-semibold">{q.title}</div>
                <div className="text-sm opacity-80">{q.desc}</div>
              </div>
              <div className="text-sm">
                <span className="px-2 py-1 rounded-full bg-slate-700">{q.status}</span>
              </div>
            </div>
            <div className="mt-2 flex items-center justify-between">
              <div className="text-sm opacity-90">Reward: {q.rewardXp} XP</div>
              <div className="flex gap-2">
                {q.status==='completed' && <button onClick={()=>claim(q)} className="bg-emerald-600 px-3 py-1 rounded">Claim</button>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}