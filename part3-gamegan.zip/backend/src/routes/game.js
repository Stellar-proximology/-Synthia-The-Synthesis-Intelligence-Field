// backend/src/routes/game.js
const express = require('express');
const router = express.Router();
const Progress = require('../models/Game');

// Helpers
async function getOrCreate(user='anon'){
  let p = await Progress.findOne({ user });
  if(!p){
    p = new Progress({ user, badges: [], quests: [] });
    await p.save();
  }
  return p;
}

// GET /game/progress?user=anon
router.get('/progress', async (req,res)=>{
  try{
    const user = req.query.user || 'anon';
    const p = await getOrCreate(user);
    res.json(p);
  }catch(e){ res.status(500).json({ error: e.message }); }
});

// POST /game/seed  -> seeds a few quests
router.post('/seed', async (req,res)=>{
  try{
    const user = req.body.user || 'anon';
    const p = await getOrCreate(user);
    if(!p.quests.length){
      p.quests = [
        { id:'q1', title:'First Pulse', desc:'Log any impulse (Heart).', status:'available', rewardXp:10, field:'Heart' },
        { id:'q2', title:'Think It Through', desc:'Record a Mind thought.', status:'available', rewardXp:15, field:'Mind' },
        { id:'q3', title:'Take Action', desc:'Post a Body action.', status:'available', rewardXp:20, field:'Body' },
        { id:'q4', title:'Unlock a Gate', desc:'Complete any gate on the Swarm map.', status:'available', rewardXp:25 },
      ];
    }
    await p.save();
    res.json({ ok:true, quests:p.quests });
  }catch(e){ res.status(500).json({ error:e.message }); }
});

// POST /game/event  -> { user, type, field?, gate?, channel? }
router.post('/event', async (req,res)=>{
  try{
    const { user='anon', type, field=null, gate=null, channel=null } = req.body || {};
    const p = await getOrCreate(user);
    // XP rules
    let delta = 0;
    if(type==='thought'){
      if(channel==='impulse') delta = 5;
      else if(channel==='thought') delta = 8;
      else if(channel==='action') delta = 12;
    }else if(type==='gateComplete'){
      delta = 25;
      if(typeof gate==='number' && [16,62,34,57].includes(gate)) delta += 10; // sample affinities
    }else{
      delta = 1;
    }
    p.addXp(delta);

    // Quest auto-progress
    p.quests = (p.quests || []).map(q=>{
      if(q.status==='claimed') return q;
      if(q.id==='q1' && channel==='impulse') q.status='completed';
      if(q.id==='q2' && channel==='thought') q.status='completed';
      if(q.id==='q3' && channel==='action') q.status='completed';
      if(q.id==='q4' && type==='gateComplete') q.status='completed';
      return q;
    });

    await p.save();
    res.json({ ok:true, xpDelta: delta, progress: p });
  }catch(e){ res.status(500).json({ error:e.message }); }
});

// POST /game/claim -> { user, questId }
router.post('/claim', async (req,res)=>{
  try{
    const { user='anon', questId } = req.body || {};
    const p = await getOrCreate(user);
    const q = (p.quests||[]).find(x=>x.id===questId);
    if(!q) return res.status(404).json({ error:'quest not found' });
    if(q.status!=='completed') return res.status(400).json({ error:'quest not completed' });
    // grant XP and badge
    p.addXp(q.rewardXp);
    q.status='claimed';
    if(questId==='q3' && !p.badges.includes('Action Taker')) p.badges.push('Action Taker');
    await p.save();
    res.json({ ok:true, progress: p });
  }catch(e){ res.status(500).json({ error:e.message }); }
});

module.exports = router;