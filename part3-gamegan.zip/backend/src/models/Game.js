// backend/src/models/Game.js
const mongoose = require('mongoose');

const QuestSchema = new mongoose.Schema({
  id: { type: String, required: true },
  title: String,
  desc: String,
  status: { type: String, enum: ['available','active','completed','claimed'], default: 'available' },
  rewardXp: { type: Number, default: 10 },
  field: { type: String, enum: ['Body','Heart','Mind', null], default: null },
  gate: { type: Number, default: null },
}, { _id: false });

const ProgressSchema = new mongoose.Schema({
  user: { type: String, default: 'anon', index: true },
  xp: { type: Number, default: 0 },
  level: { type: Number, default: 1 },
  badges: [{ type: String }],
  quests: [QuestSchema],
  updatedAt: { type: Date, default: Date.now }
});

ProgressSchema.methods.addXp = function(pts){
  this.xp += pts;
  // simple level curve: 100 xp per level
  const target = Math.max(1, Math.floor(this.xp / 100) + 1);
  if (target > this.level) this.level = target;
  this.updatedAt = new Date();
};

module.exports = mongoose.model('Progress', ProgressSchema);