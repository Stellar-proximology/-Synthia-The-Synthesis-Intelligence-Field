
# speech_engine.py

def modulate_voice(sentence, tone=3):
    return f"[Tone {tone} modulated voice]: {sentence}"
