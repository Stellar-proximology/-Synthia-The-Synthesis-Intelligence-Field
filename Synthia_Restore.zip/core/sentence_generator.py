
# sentence_generator.py

def generate_resonant_sentence(gate, line, color, tone, base):
    return f"I express Gate {gate}.{line} through Color {color}, Tone {tone}, and Base {base}."
