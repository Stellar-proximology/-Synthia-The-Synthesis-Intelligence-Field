
# cynthia_core.py

class CynthiaCore:
    def __init__(self, user_chart):
        self.chart = user_chart
        self.memory = []

    def respond(self, prompt):
        return f"Based on your field, here's my insight: {prompt}"
