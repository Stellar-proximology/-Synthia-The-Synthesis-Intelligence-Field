
# cerebrum.py

from .cynthia_core import CynthiaCore

class CerebrumInterface:
    def __init__(self, chart_data):
        self.cynthia = CynthiaCore(chart_data)

    def get_field_reflection(self, user_input):
        return self.cynthia.respond(user_input)
